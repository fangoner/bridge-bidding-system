import { useEffect, useRef, useCallback, useMemo, useState } from 'react'
import {
  Container,
  Typography,
  Button,
  Box,
  Paper,
  Alert,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Switch,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Divider,
  Badge,
  ToggleButtonGroup,
  ToggleButton,
  LinearProgress,
  useTheme,
  useMediaQuery
} from '@mui/material'
import DeleteIcon from '@mui/icons-material/Delete'
import EditIcon from '@mui/icons-material/Edit'
import HistoryIcon from '@mui/icons-material/History'
import { aiBid, analyzeBidding, humanBid, getOutputFormats, analyzeContract, doubleDummyAnalysis, playInit, playCard, aiPlay, getPlayState, updatePlayPlayerRoles, undoPlay, setPlayHand, getDDHints, getDDHintsReview, customDeal as apiCustomDeal } from './services/api'
import HandDisplay from './components/HandDisplay'
import Header from './components/layout/Header'
import BiddingDetailPanel from './components/BiddingDetailPanel'
import CardTablePanel from './components/CardTablePanel'
import MainTableArea from './components/MainTableArea'
import SettingsPanel from './components/SettingsPanel'
import PlayPanel from './components/PlayPanel'
import PlayDetailPanel from './components/PlayDetailPanel'
import HistoryDialog from './components/HistoryDialog'
import useBridgeRecords from './hooks/useBridgeRecords'
import useModelSettings from './hooks/useModelSettings'
import useDealing from './hooks/useDealing'
import { BRIDGE_POSITIONS } from './utils/position'
import { validateHands, validateBidding } from './utils/validation'
import { formatElapsedTime } from './utils/biddingUtils'
import './App.css'

/** 拼装一条叫牌含义行（含结构化叫品约束，供打牌通道A解析）：(位置)叫品: 含义[约束:...] */
const formatBidMeaningLine = (r) => {
  const meaning = r.result?.meaning || ''
  const constraint = r.result?.full_output?.['叫品约束'] || ''
  const cText = constraint ? `[约束:${constraint}]` : ''
  return `(${r.position})${r.result?.bid || ''}: ${meaning}${cText}`
}

/** 确保手牌每门花色按 A→2 排序，并计算 HCP */
const ensureSortedHands = (hands) => {
  if (!hands || typeof hands !== 'object') return hands
  const rankOrder = 'AKQJT98765432'
  const sortSuit = (s) => {
    if (!s || typeof s !== 'string') return ''
    return s.split('').sort((a, b) => rankOrder.indexOf(a) - rankOrder.indexOf(b)).join('')
  }
  const calcHCP = (cards) => {
    let h = 0
    for (const c of cards.toUpperCase()) {
      if (c === 'A') h += 4
      else if (c === 'K') h += 3
      else if (c === 'Q') h += 2
      else if (c === 'J') h += 1
    }
    return h
  }
  const suits = ['spades', 'hearts', 'diamonds', 'clubs']
  const result = { ...hands }
  for (const p of Object.keys(result)) {
    const h = result[p]
    if (h && typeof h === 'object') {
      let allCards = ''
      for (const sk of suits) {
        h[sk] = sortSuit(h[sk] || '')
        allCards += h[sk]
      }
      h.hcp = calcHCP(allCards)
    }
  }
  return result
}
import { GameProvider, useGame } from './context/GameContext'
import { BiddingProvider, useBidding } from './context/BiddingContext'
import { PlayProvider, usePlay } from './context/PlayContext'
import { AIProgressProvider, useAIProgressSetter } from './context/AIProgressContext'

const BIDDING_DRAFT_KEY = 'bridge_bidding_draft'

// 将当前手牌转换为自定义牌局文本格式（带花色符号，便于阅读编辑）
const handsToEditText = (handsObj) => {
  if (!handsObj) return ''
  const order = ['南', '西', '北', '东']
  const suitSymbols = ['♠', '♥', '♦', '♣']
  const suitKeys = ['spades', 'hearts', 'diamonds', 'clubs']
  return order.map(pos => {
    const hand = handsObj[pos]
    if (!hand) return ''
    return suitKeys.map((k, i) => {
      const cards = hand[k] || ''
      return cards ? `${suitSymbols[i]}${cards}` : `${suitSymbols[i]}-`
    }).join(' ')
  }).join('\n')
}

// 将叫牌序列转换为编辑文本
const biddingToEditText = (seq) => {
  if (!seq || seq.length === 0) return ''
  return seq.map(b => `(${b.position})${b.bid}`).join('-')
}

function AppShell({ darkMode, onToggleDarkMode }) {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'))
  
  const isLoadingRecordRef = useRef(false) // 用于标记是否正在加载历史记录（不触发保存）
  const draftRestoredRef = useRef(false) // 防止重复恢复草稿
  const draftSaveTimerRef = useRef(null) // debounce 叫牌草稿自动保存
  const lastBidTimeRef = useRef(null) // 上一条叫牌记录完成的时间戳，用于计算单次耗时
  const biddingStartTimeRef = useRef(null) // 同步存储叫牌开始时间，避免 React state 异步问题
  // AI 轮询进度文案 setter（独立 Context，文案更新不触发本组件重渲染）
  const setAiProgress = useAIProgressSetter()
  // ── Game 域状态（迁入 GameContext）──
  const {
    hands, setHands,
    loading, setLoading,
    aiThinking, setAiThinking,
    error, setError,
    warning, setWarning,
    gameMode, setGameMode,
    dealer, setDealer,
    vulnerability,
    practiceDirection, setPracticeDirection,
    positionRoles, setPositionRoles,
    setShowPartnerHand,
    setShowOpponentHands,
    useFallback, setUseFallback,
    dealMode, setDealMode,
    showSettings, setShowSettings,
    dealSystem, setDealSystem,
    bidSystem, setBidSystem,
    humanBidInterpret, setHumanBidInterpret,
    fallbackModel,
    playModel,
    apiStatus,
    currentRecordId, setCurrentRecordId,
    showDraftBanner, setShowDraftBanner,
    customDealOpen, setCustomDealOpen,
    imageDealOpen, setImageDealOpen,
    imagePath, setImagePath,
    imageFile, setImageFile,
    imageOpeningLead, setImageOpeningLead,
    mode, setMode,
    setReadonlyMode,
    readonlyMode,
  } = useGame()

  // 修正手牌/编辑叫牌对话框的校验信息（仅在该对话框内显示）
  const [handsValidationError, setHandsValidationError] = useState([])
  const [handsValidationWarning, setHandsValidationWarning] = useState([])
  const [biddingValidationError, setBiddingValidationError] = useState([])
  const [biddingValidationWarning, setBiddingValidationWarning] = useState([])
  // 修正手牌对话框编辑文本（局部 state，避免每次按键触发全局 context 重渲染导致迟滞）
  const [customDealText, setCustomDealText] = useState('')
  // 编辑叫牌序列对话框编辑文本（局部 state，同理避免全局重渲染迟滞）
  const [editBiddingText, setEditBiddingText] = useState('')
  // 直接打牌对话框表单 & 重置首攻值（局部 state，避免输入时触发全局 context 重渲染迟滞）
  const [contractDialogForm, setContractDialogForm] = useState({
    contractStr: '', declarer: '南', openingLead: '',
    isDouble: false, isRedouble: false,
  })
  const [resetOpeningLeadValue, setResetOpeningLeadValue] = useState('')

  // ── Bidding 域状态（迁入 BiddingContext）──
  const {
    biddingSequence, setBiddingSequence,
    currentBidder, setCurrentBidder,
    setBidSuggestion,
    aiBiddingHistory, setAiBiddingHistory,
    currentBiddingPosition, setCurrentBiddingPosition,
            biddingStarted, setBiddingStarted,
    stopBidding, setStopBidding,
    passedAIPositions, setPassedAIPositions,
    biddingStartTime,
    setBiddingTotalTime,
    customBidMeaning, setCustomBidMeaning,
    setSuggestionLoading,
    isBiddingComplete,
    initBiddingState,
    toggleStopBiddingState,
    markBiddingStarted,
    biddingHistory, setBiddingHistory,
    historyIndex, setHistoryIndex,
    showEditBiddingDialog, setShowEditBiddingDialog,
    outputFormats, setOutputFormats,
    setOutputFormatsLoading,
    setAnalyzeLoading,
    setAnalyzeResult,
    setShowDoubleDummy,
    doubleDummyResult,
    setDoubleDummyResult,
    setDoubleDummyLoading,
  } = useBidding()

  // ── Play 域状态（迁入 PlayContext）──
  const {
    playState, setPlayState,
    playLoading, setPlayLoading,
    showPlayPanel, setShowPlayPanel,
    setShowPlayedCards,
    setPlayCenterView,
    isPlayPaused, setIsPlayPaused,
    setLastCompletedTrick,
    aiPlayHistory, setAiPlayHistory,
    setSelectedPlayRecord,
    setPlayStarted,
    playInitiated, setPlayInitiated,
    loadedPlayRecord, setLoadedPlayRecord,
    reviewCursor, setReviewCursor,
    showDDHints,
    setDDHints,
    setDDHintsLoading,
    contractDialogOpen, setContractDialogOpen,
    resetOpeningLeadDialogOpen, setResetOpeningLeadDialogOpen,
    directPlayContractInfo, setDirectPlayContractInfo,
    playEngine,
    handlePlayEngineChange,
    setPlayStartTime,
    useLlmReview,
    handleLlmReviewChange,
  } = usePlay()

  // 载入已完成牌局时的操作选择：null=未决定, 'replay'=只重新打牌, 'review'=复盘
  const [recordActionDialogOpen, setRecordActionDialogOpen] = useState(false)
  const [recordActionMode, setRecordActionMode] = useState(null)

  // ── 打牌总耗时（v1.61）：进入打牌时记录开始时间，完成后计算总时长并显示 ──
  const playStartTimeRef = useRef(null)
  const [playTotalTime, setPlayTotalTime] = useState(null)

  // ── P1-9：回放进度（回放历史已出牌时的"N/M 张"提示）──
  const [replayProgress, setReplayProgress] = useState(null)

  // 页面加载时检测是否有未完成的叫牌草稿
  useEffect(() => {
    try {
      const draftStr = localStorage.getItem(BIDDING_DRAFT_KEY)
      if (!draftStr) return
      const draft = JSON.parse(draftStr)
      // 超过 2 小时的草稿视为过期
      if (Date.now() - draft.timestamp > 2 * 60 * 60 * 1000) {
        localStorage.removeItem(BIDDING_DRAFT_KEY)
        return
      }
      setShowDraftBanner(true)
    } catch {
      localStorage.removeItem(BIDDING_DRAFT_KEY)
    }
  }, [setShowDraftBanner])

  // 清除叫牌草稿
  const clearBiddingDraft = () => {
    try {
      localStorage.removeItem(BIDDING_DRAFT_KEY)
    } catch { /* ignore */ }
    setShowDraftBanner(false)
  }

  // 恢复叫牌草稿
  const restoreBiddingDraft = () => {
    try {
      const draftStr = localStorage.getItem(BIDDING_DRAFT_KEY)
      if (!draftStr) return
      const draft = JSON.parse(draftStr)
      draftRestoredRef.current = true
      // 确保草稿手牌经过排序和 HCP 计算（兼容旧版草稿）
      const sortedDraftHands = ensureSortedHands(draft.hands)
      setHands(sortedDraftHands)
      setDealer(draft.dealer)
      setGameMode(draft.gameMode)
      setPositionRoles(draft.positionRoles)
      if (draft.practiceDirection) setPracticeDirection(draft.practiceDirection)
      setDealSystem(draft.dealSystem)
      setDealMode(draft.dealMode)
      setBiddingSequence(draft.biddingSequence)
      setCurrentBidder(draft.currentBidder)
      setAiBiddingHistory(draft.aiBiddingHistory)
      setBiddingHistory(draft.biddingHistory || [])
      setHistoryIndex(draft.historyIndex ?? -1)
      setBiddingStarted(draft.biddingStarted)
      setStopBidding(draft.stopBidding)
      setPassedAIPositions(new Set(draft.passedAIPositions || []))
      setShowDraftBanner(false)
    } catch (e) {
      console.warn('恢复叫牌草稿失败:', e)
      clearBiddingDraft()
    }
  }
  // 游戏设置状态已迁入 GameContext（useGame）
  // Bidding 域输出格式/分析状态已迁入 BiddingContext（useBidding）
  
  
  // 牌局记录管理（叫牌+打牌统一存储）
  const {
    records: bridgeRecords,
    historyDialogOpen, setHistoryDialogOpen,
    loadRecords: loadBridgeRecords,
    fetchFullRecord, fetchFullRecords,
    saveRecord: saveBridgeRecord,
    deleteRecords: deleteBridgeRecords,
    updateRecordNote,
    importRecords,
  } = useBridgeRecords()
  // 牌局对话框状态已迁入 GameContext
  // 双明手分析状态已迁入 BiddingContext
  // Play 域状态已迁入 PlayContext（usePlay）

  const prevTricksCountRef = useRef(0) // 用于检测一墩完成
  const playStateRef = useRef(playState)
  const aiPlayHistoryRef = useRef(aiPlayHistory)
  const abortControllerRef = useRef(null)
  const bidAbortRef = useRef(null) // 在途 AI 叫牌请求（支持暂停中止，P1 修复）
  const humanBidInFlightRef = useRef(false) // P2-4：人类叫牌处理中（含含义获取）防重复点击
  const playCardInFlightRef = useRef(false) // P2-5：出牌请求在途时防连点
  const aiPlayInFlightRef = useRef(false) // v1.61：AI 出牌请求在途（含乐观更新窗口），防同一回合重复调度
  const undoSeqRef = useRef(0) // 撤销序号：出牌请求在途期间发生撤销时，丢弃过期响应避免覆盖撤销结果
  const aiBiddingHistoryRef = useRef(aiBiddingHistory) // 叫牌历史 ref：同步追踪最新值
  useEffect(() => { playStateRef.current = playState }, [playState])
  useEffect(() => { aiPlayHistoryRef.current = aiPlayHistory }, [aiPlayHistory])
  useEffect(() => { aiBiddingHistoryRef.current = aiBiddingHistory }, [aiBiddingHistory])

  // 追加叫牌历史：同步更新 ref + 设置 state，返回新数组。
  // 修复根因：原代码人类/AI 用函数式更新、双人自动pass 用闭包直接值，
  // React 直接值会替换函数式更新 → 真实叫牌记录被自动pass覆盖丢失（历史只剩跳过信息）
  const appendBidHistory = useCallback((record) => {
    const next = [...aiBiddingHistoryRef.current, record]
    aiBiddingHistoryRef.current = next
    setAiBiddingHistory(next)
    return next
  }, [])

  // ── 模型配置 hook（备用模型/打牌模型/DD采样/API状态/JF重载）──
  const {
    ddSampleCount,
    handleDDSampleCountChange,
    ddParticles, ddParticlesRange,
    mctsParticles, mctsParticlesRange,
    alphaMuParticles, alphaMuParticlesRange,
    handleParticleChange,
    switchCards, switchCardsRange,
    handleSwitchCardsChange,
    ddScoringMode, handleDdScoringModeChange,
    handleFallbackModelChange,
    handlePlayModelChange,
    checkApiStatus,
    handleReloadJF,
    parseModelValue,
    availableModels,
  } = useModelSettings()

  // 检查API状态（历史记录改为打开历史对话框时按需加载，不在启动时常驻）
  useEffect(() => {
    checkApiStatus()
  }, [checkApiStatus])



  // Strip redundant playState fields already in board before storing
  const stripPlayState = (ps) => {
    if (!ps) return null
    const { contract: _c, bidding_sequence: _b, player_roles: _p, dummy: _d, is_human_turn: _h, ...rest } = ps
    return rest
  }

  // 存盘时裁剪：去掉 prompt（巨大文本不显示），保留 reasoning/follow_up/full_output
  const trimPlayHistory = (h) => {
    if (!h) return []
    return h.map(({ prompt, ...rest }) => rest)
  }
  // 裁剪叫牌历史：去掉 hand/biddingSequence（board已存），保留完整 result（含 LLM 输出）
  const trimBiddingHistory = (h) => {
    if (!h) return []
    return h.map(({ hand: _h, biddingSequence: _bs, ...rest }) => ({
      ...rest,
      hand: _h,
    }))
  }

  // 生成叫牌时间戳：累计时间 (单次耗时)
  // individualMs: 单次耗时毫秒，AI 调用在 await 后直接传入，避免 React 渲染延迟
  const makeBidTimestamp = useCallback((individualMs = null) => {
    const now = Date.now()
    const start = biddingStartTimeRef.current
    if (!start) {
      console.warn('[makeBidTimestamp] biddingStartTimeRef is falsy, state=', biddingStartTime)
    }
    const effectiveStart = start || biddingStartTime || now
    const cumulative = formatElapsedTime(now - effectiveStart)
    let individual = ''
    // 只有非首个叫品才显示单次耗时（首个叫品没有上一条可参照）
    if (lastBidTimeRef.current) {
      if (individualMs !== null) {
        // AI 调用：用传入的精确耗时
        individual = individualMs >= 1000 ? `${Math.round(individualMs / 1000)}s` : `${individualMs}ms`
      } else {
        // 人类叫牌：距上一条记录的时间差
        const ms = now - lastBidTimeRef.current
        individual = ms >= 1000 ? `${Math.round(ms / 1000)}s` : `${ms}ms`
      }
    }
    lastBidTimeRef.current = now
    return individual ? `${cumulative} (+${individual})` : cumulative
  }, [biddingStartTime])


  // 加载历史记录到牌桌
  const loadRecordToTable = (record) => {
    isLoadingRecordRef.current = true
    // 设置当前记录ID，用于后续覆盖保存
    setCurrentRecordId(record.id)
    // 兼容新旧格式
    const board = record.board || record
    const bidding = record.bidding || record
    // 有打牌记录 → 从 tricks 重建完整四家手牌，完成后不区分来源
    let resolvedHands = board.hands || record.hands || {}
    // 从打牌记录 tricks 重建完整四家手牌（仅当顶层手牌不完整时，兼容旧记录/仅存打牌数据的导入）
    const playTricks = record.play?.tricks
    const savedPlayState = record.play?.state
    const hasPlayState = !!(playTricks && playTricks.length > 0) || !!savedPlayState
    const hasFullHands = !!resolvedHands && ['南', '北', '东', '西'].every(p => {
      const h = resolvedHands[p]
      return h && (h.spades?.length || 0) + (h.hearts?.length || 0) + (h.diamonds?.length || 0) + (h.clubs?.length || 0) === 13
    })
    if (hasPlayState && !hasFullHands) {
      const ALL_POS = ['北', '东', '南', '西']
      const playedByPos = Object.fromEntries(ALL_POS.map(p => [p, []]))
      for (const t of playTricks || []) {
        for (const [p, c] of (t.cards || [])) playedByPos[p].push(c)
      }
      const sm = { '♠': 'spades', '♥': 'hearts', '♦': 'diamonds', '♣': 'clubs' }
      resolvedHands = {}
      for (const p of ALL_POS) {
        const hand = { spades: '', hearts: '', diamonds: '', clubs: '' }
        const seen = new Set()
        for (const c of (playedByPos[p] || [])) {
          const key = `${c.suit}${c.rank}`
          if (!seen.has(key)) { seen.add(key); const sk = sm[c.suit]; if (sk) hand[sk] += c.rank }
        }
        resolvedHands[p] = hand
      }
    }
    setHands(ensureSortedHands(resolvedHands))
    setBiddingSequence(board.bidding_sequence || record.biddingSequence || [])
    setDealer(board.dealer || record.dealer)
    setImageOpeningLead(board.opening_lead || null)
    // 有打牌记录时不恢复 gameMode，完成后与发牌练习走同样路径
    if (!hasPlayState && (board.game_mode || record.gameMode)) {
      setGameMode(board.game_mode || record.gameMode)
    }
    if (board.practice_direction) {
      setPracticeDirection(board.practice_direction)
    }
    if (board.position_roles) {
      setPositionRoles(board.position_roles)
    } else if (board.human_position || record.humanPosition) {
      // 兼容旧格式：从 human_position 转换
      const hp = board.human_position || record.humanPosition
      const positions = ['北', '南', '东', '西']
      const humans = Array.isArray(hp) ? hp : [hp]
      const newRoles = Object.fromEntries(positions.map(p => [p, humans.includes(p) ? 'human' : 'ai']))
      setPositionRoles(newRoles)
    }
    setAiBiddingHistory(bidding.ai_bidding_history || record.aiBiddingHistory || [])
    if (bidding.deal_system || record.dealSystem) {
      setDealSystem(bidding.deal_system || record.dealSystem)
    }
    setBiddingStarted(true)
    setStopBidding(true) // 加载历史记录后允许切换发牌人
    setShowPartnerHand(true)
    setShowOpponentHands(true)
    setHistoryDialogOpen(false)
    setOutputFormats(null) // 重置输出格式
    setShowDoubleDummy(false) // 切换到显示叫牌过程
    setDoubleDummyResult(null) // 清除双明手结果
    // 清除上一副牌残留的打牌状态，避免桌面显示旧牌
    setLastCompletedTrick(null)
    setReviewCursor(null)
    setSelectedPlayRecord(null)
    // 预加载打牌数据
    if (record.play && (playTricks?.length > 0 || savedPlayState)) {
      // 完整记录含 tricks 数组
      const contractFromRecord = board.contract
      const suitMap = { S: '♠', H: '♥', D: '♦', C: '♣', NT: 'NT' }
      const partnerMap = { '北': '南', '南': '北', '东': '西', '西': '东' }

      const contract = contractFromRecord ? {
        level: contractFromRecord.level,
        suit: suitMap[contractFromRecord.suit] || contractFromRecord.suit || 'NT',
        declarer: contractFromRecord.declarer,
        doubled: contractFromRecord.isDouble || false,
        redoubled: contractFromRecord.isRedouble || false,
        tricks_needed: (contractFromRecord.level || 0) + 6,
      } : null

      let restoredPlayState
      if (savedPlayState && savedPlayState.phase && savedPlayState.phase !== 'complete') {
        // P2 修复：进行中记录（play_in_progress）直接恢复保存的状态（含真实 phase/current_trick），
        // 支持断点续打；stripPlayState 已剥离 contract/player_roles/dummy，需重新挂接
        restoredPlayState = {
          ...savedPlayState,
          contract,
          player_roles: savedPlayState.player_roles || board.player_roles || board.position_roles || {},
          dummy: contract ? partnerMap[contract.declarer] : null,
          is_human_turn: false,
        }
      } else {
        // 完整记录（play_complete，无 state）：从 tricks 重建完成态
        restoredPlayState = {
          contract,
          hands: { '北': [], '南': [], '东': [], '西': [] },
          dummy: contract ? partnerMap[contract.declarer] : null,
          player_roles: board.player_roles || {},
          tricks: playTricks || [],
          current_trick: { cards: [], leader: null, trump: contract?.suit || null },
          current_player: null,
          lead_player: null,
          declarer_tricks: record.play.declarer_tricks || 0,
          defender_tricks: record.play.defender_tricks || 0,
          phase: 'complete',
          is_human_turn: false,
        }
      }

      setLoadedPlayRecord({
        playState: restoredPlayState,
        aiPlayHistory: record.play.ai_play_history || [],
      })
    }
    setShowPlayPanel(hasPlayState)
    setPlayState(null)
    setAiPlayHistory([])
    setIsPlayPaused(false)

    // 判断手牌齐全：四家各13张 → 恢复4AI可操作；不齐全 → 只读
    // 用重建后的 resolvedHands（含从 tricks 重建的手牌）
    const allComplete = resolvedHands && ['南','北','东','西'].every(pos => {
      const h = resolvedHands[pos]
      if (!h) return false
      const total = (h.spades?.length || 0) + (h.hearts?.length || 0) + (h.diamonds?.length || 0) + (h.clubs?.length || 0)
      return total === 13
    })
    if (allComplete) {
      setPositionRoles({ '南': 'ai', '北': 'ai', '东': 'ai', '西': 'ai' })
      setReadonlyMode(false)
    } else {
      // 手牌不全时不锁定界面：模拟实战中人类手牌未知是正常的，
      // 用户应能重新叫牌、编辑叫牌、切换角色、补输手牌
      setReadonlyMode(false)
    }

    // 加载历史记录后获取更多输出格式
    if ((board.hands || record.hands) && (board.bidding_sequence || record.biddingSequence) && (board.bidding_sequence || record.biddingSequence).length > 0) {
      // 延迟调用，确保状态已更新
      setTimeout(() => {
        fetchOutputFormatsForRecord(record)
        isLoadingRecordRef.current = false
      }, 100)
    } else {
      isLoadingRecordRef.current = false
    }
  }
  
  // 为历史记录获取输出格式
  const fetchOutputFormatsForRecord = async (record) => {
    // 兼容新旧格式
    const hands = record.board?.hands || record.hands
    const biddingSequence = record.board?.bidding_sequence || record.biddingSequence
    const dealer = record.board?.dealer || record.dealer
    
    if (!hands || !biddingSequence || biddingSequence.length === 0) return
    
    setOutputFormatsLoading(true)
    try {
      const biddingStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-')
      console.log('[DEBUG] 加载历史记录获取输出格式, biddingStr:', biddingStr, 'dealer:', dealer)
      const result = await getOutputFormats(hands, biddingStr, dealer, gameMode, positionRoles, imageOpeningLead)
      console.log('[DEBUG] 输出格式结果:', result)
      setOutputFormats(result)
    } catch (err) {
      console.error('获取输出格式失败:', err)
    } finally {
      setOutputFormatsLoading(false)
    }
  }

  // 叫牌回退功能
  const undoBidding = useCallback(() => {
    if (historyIndex > 0) {
      const snapshot = biddingHistory[historyIndex - 1]
      setBiddingSequence(snapshot.biddingSequence)
      setCurrentBidder(snapshot.currentBidder)
      // snapshot.aiBiddingHistory 可能比 biddingSequence 少一条（React 批处理时序问题），
      // 用 biddingSequence 长度截断 aiBiddingHistory 保证两者一致
      const targetLen = snapshot.biddingSequence.length
      setAiBiddingHistory(prev => prev.slice(0, targetLen))
      setHistoryIndex(historyIndex - 1)
      setBidSuggestion(null)
    }
  }, [biddingHistory, historyIndex, setAiBiddingHistory, setBidSuggestion, setBiddingSequence, setCurrentBidder, setHistoryIndex])

  // 只有停止叫牌后才能撤销，且AI不在加载中（包括AI叫牌和获取叫品含义）
  const showUndo = stopBidding && historyIndex > 0
  const canUndo = !aiThinking && !currentBiddingPosition

  // 判断是否可以保存进度（叫牌模式）
  const canSaveProgress = hands && !showPlayPanel && biddingStarted && !isBiddingComplete() && stopBidding

  // 打牌模式下是否可以保存
  const playCanSave = showPlayPanel && playState && playState.phase !== 'complete' && isPlayPaused

  // 手动保存进度（使用ref避免playState/aiPlayHistory变化导致回调重建）
  const handleSaveProgress = useCallback(() => {
    if (!hands || !biddingSequence || biddingSequence.length === 0) return
    const ps = playStateRef.current
    const aph = aiPlayHistoryRef.current

    // 打牌进行中：保存打牌状态
    if (showPlayPanel && ps && ps.phase !== 'complete') {
      // 从第一墩第一张牌提取首攻（如果 imageOpeningLead 为空）
      let saveOpeningLead = imageOpeningLead || undefined
      if (!saveOpeningLead && ps.tricks?.length > 0) {
        const firstTrick = ps.tricks[0]
        if (firstTrick.cards?.length > 0) {
          const [leadPos, leadCard] = firstTrick.cards[0]
          saveOpeningLead = `${leadPos}:${leadCard.suit}${leadCard.rank}`
        }
      }
      const record = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleString(),
        type: 'play_in_progress',
        sourceRecordId: currentRecordId || undefined,
        board: {
          hands: hands,
          bidding_sequence: biddingSequence,
          contract: ps.contract ? {
            level: ps.contract.level,
            suit: ps.contract.suit,
            declarer: ps.contract.declarer,
            isDouble: ps.contract.is_double,
            isRedouble: ps.contract.is_redouble,
          } : null,
          dealer: dealer,
          game_mode: gameMode,
          practice_direction: practiceDirection,
          position_roles: positionRoles,
          player_roles: positionRoles,
          opening_lead: saveOpeningLead,
        },
        bidding: {
          ai_bidding_history: trimBiddingHistory(aiBiddingHistory),
          deal_system: dealSystem,
        },
        play: {
          state: stripPlayState(ps),
          ai_play_history: trimPlayHistory(aph),
        },
        note: ''
      }
      saveBridgeRecord(record)
      if (!currentRecordId) {
        setCurrentRecordId(record.id)
      }
      return
    }

    // 叫牌进行中：保存叫牌状态
    const record = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString(),
      type: 'bidding_in_progress',
      sourceRecordId: currentRecordId || undefined,
      board: {
        hands: hands,
        bidding_sequence: biddingSequence,
        contract: null,
        dealer: dealer,
        game_mode: gameMode,
        practice_direction: practiceDirection,
        position_roles: positionRoles,
        opening_lead: imageOpeningLead || undefined,
      },
      bidding: {
        ai_bidding_history: trimBiddingHistory(aiBiddingHistory),
        deal_system: dealSystem,
      },
      play: null,
      note: ''
    }
    saveBridgeRecord(record)
    if (!currentRecordId) {
      setCurrentRecordId(record.id)
    }
  }, [hands, biddingSequence, dealer, gameMode, practiceDirection, positionRoles, aiBiddingHistory, dealSystem, currentRecordId, showPlayPanel])

  // ── 发牌流程 hook（发牌/自定义牌局/图片识别/截屏识别/清除手牌）──
  const {
    handleDeal,
    handleImageDeal,
    handleScreenshotDeal,
    handleBiddingScreenshot,
    handleBiddingImageUpload,
    handleSingleHandScreenshot,
    handleSingleHandUpload,
    clearAllHands,
    parseBiddingSequenceStr,
    cancelScreenshot,
    screenshotStatus,
    loading: dealingLoading,
  } = useDealing({ clearBiddingDraft })

  // 截屏识别需要关闭设置面板
  const onScreenshotDeal = useCallback(() => handleScreenshotDeal({ setShowSettings }), [handleScreenshotDeal, setShowSettings])

  // 中心面板识别叫牌过程：仅在未开始叫牌且尚无叫牌序列时可用
  // 桌面点击走剪贴板截屏流程；移动端从图库选图后以 File 参数回调，走上传识别路径
  const showBiddingScreenshotBtn = !showPlayPanel && !biddingStarted && (biddingSequence?.length || 0) === 0 && !readonlyMode
  const onScreenshotBidding = useMemo(
    () => showBiddingScreenshotBtn
      ? (file) => file ? handleBiddingImageUpload(file) : handleBiddingScreenshot({ setShowSettings })
      : null,
    [showBiddingScreenshotBtn, handleBiddingImageUpload, handleBiddingScreenshot, setShowSettings]
  )

  // 开始叫牌
  const startBidding = useCallback(() => {
    if (hands) {
      // 检查AI位置是否都有手牌
      const aiPositions = Object.entries(positionRoles)
        .filter(([, role]) => role === 'ai')
        .map(([pos]) => pos)

      for (const pos of aiPositions) {
        const hand = hands[pos]
        if (!hand || (!hand.spades && !hand.hearts && !hand.diamonds && !hand.clubs)) {
          setError(`${pos}家(AI)没有手牌，请先输入手牌`)
          return
        }
      }

      // 重置叫牌序列并标记开始
      setBiddingSequence([])
      setCurrentBidder(dealer)
      markBiddingStarted()
      biddingStartTimeRef.current = Date.now() // 同步记录，避免 React state 延迟
      setAiBiddingHistory([])
      setStopBidding(false)
      setPassedAIPositions(new Set())
      setBiddingTotalTime(null)
      setError(null)
      lastBidTimeRef.current = null
      // 重置回退历史并保存初始快照
      const initialSnapshot = {
        biddingSequence: [],
        currentBidder: dealer,
        aiBiddingHistory: [],
      }
      setBiddingHistory([initialSnapshot])
      setHistoryIndex(0)
    }
  }, [hands, positionRoles, dealer, setError, setBiddingSequence, setCurrentBidder, markBiddingStarted, setAiBiddingHistory, setStopBidding, setPassedAIPositions, setBiddingTotalTime, setBiddingHistory, setHistoryIndex])

  // 重新叫牌（保持当前牌局）
  const resetBidding = () => {
    clearBiddingDraft()
    initBiddingState(dealer)
    setBiddingHistory([])
    setHistoryIndex(-1)
    setLoadedPlayRecord(null)
    setCurrentRecordId(null)
    lastBidTimeRef.current = null
  }

  // 清除所有手牌已迁入 useDealing hook

  const handleModeChange = (newMode) => {
    if (newMode !== mode) {
      // P2 修复：切换模式会清空当前牌局（clearAllHands），有牌局时先确认，避免误触丢失进度
      const hasActiveGame = hands && Object.values(hands).some(h => h && (
        (h.spades?.length || 0) + (h.hearts?.length || 0) + (h.diamonds?.length || 0) + (h.clubs?.length || 0) > 0
      ))
      if (hasActiveGame && !window.confirm('切换模式将清空当前牌局（手牌与叫牌/打牌进度），确定继续吗？')) {
        return
      }
      setMode(newMode)
      clearAllHands()
      // 切到发牌练习：全部AI；切到模拟实战：默认3人+1AI
      if (newMode === 'practice') {
        setPositionRoles({ '南': 'ai', '北': 'ai', '东': 'ai', '西': 'ai' })
      } else {
        setPositionRoles({ '南': 'ai', '北': 'human', '东': 'human', '西': 'human' })
      }
    }
  }

  const handleDealerChange = useCallback((pos) => {
    setDealer(pos)
    // 双人模式：发牌人切换到对方阵营时自动更新练习方向，重置手牌可见性
    if (gameMode === 'pair') {
      const newDirection = ['南', '北'].includes(pos) ? 'NS' : 'EW'
      if (newDirection !== practiceDirection) {
        setPracticeDirection(newDirection)
      }
      setShowPartnerHand(false)
      setShowOpponentHands(false)
    }
    setCurrentBidder(pos)
    setBiddingStarted(false)
    setStopBidding(false)
    setBiddingSequence([])
    setAiBiddingHistory([])
    setPassedAIPositions(new Set())
    setShowPlayPanel(false)
    setPlayState(null)
    setAiPlayHistory([])
    
    setIsPlayPaused(false)
    setLoadedPlayRecord(null)
  }, [gameMode, practiceDirection, setAiBiddingHistory, setAiPlayHistory, setBiddingSequence, setBiddingStarted, setCurrentBidder, setDealer, setIsPlayPaused, setLoadedPlayRecord, setPassedAIPositions, setPlayState, setPracticeDirection, setShowOpponentHands, setShowPartnerHand, setShowPlayPanel, setStopBidding])

  // 双人模式：练习方向改变时，同步发牌人（发牌人必须在练习方阵营内）
  useEffect(() => {
    if (gameMode === 'pair' && !biddingStarted) {
      const nsDealers = ['南', '北']
      const ewDealers = ['东', '西']
      const pairDealers = practiceDirection === 'NS' ? nsDealers : ewDealers
      if (!pairDealers.includes(dealer)) {
        setDealer(pairDealers[0])
        setCurrentBidder(pairDealers[0])
      }
    }
  }, [practiceDirection, gameMode, dealer, biddingStarted, setCurrentBidder, setDealer])

  // 切换停止/继续叫牌
  const toggleStopBidding = () => {
    // P1 修复：暂停叫牌时中止在途 AI 请求，避免结果继续落盘（用户以为已停，叫品却进来了）
    if (!stopBidding && bidAbortRef.current) {
      bidAbortRef.current.abort()
    }
    toggleStopBiddingState()
  }

  // 添加叫牌
  const addBid = useCallback(async (bid) => {
    // 花色符号→字母规范化（统一显示为字母格式）
    const suitSymbolToLetter = { '♠': 'S', '♥': 'H', '♦': 'D', '♣': 'C' }
    bid = bid.replace(/[♠♥♦♣]/g, sym => suitSymbolToLetter[sym] || sym)
    const isCurrentHuman = positionRoles && positionRoles[currentBidder] === 'human'
    // 人类叫牌后，立即标记叫牌已开始（在currentBidder更新之前）
    if (isCurrentHuman && !biddingStarted) {
      setBiddingStarted(true)
    }
    
    // 人类叫牌时，保存叫牌记录
    if (isCurrentHuman) {
      // P2-4 修复：一次人类叫牌处理中（含含义获取/自定义含义等）忽略重复点击，
      // 避免快速双击连发两个叫品；用 ref 同步防重（state 异步更新会有 stale closure）
      if (humanBidInFlightRef.current) return
      humanBidInFlightRef.current = true
      try {
      // 用于显示的字符串
      const biddingStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-') + (biddingSequence.length > 0 ? '-' : '')
      
      // 如果用户输入了自定义叫牌含义，直接使用，不调用API
      if (customBidMeaning.trim()) {
        appendBidHistory({
          position: currentBidder,
          hand: hands[currentBidder],
          biddingSequence: biddingStr,
          result: { bid: bid, meaning: customBidMeaning.trim() },
          timestamp: makeBidTimestamp()
        })
        setCustomBidMeaning('') // 清空输入框
      } else if (!humanBidInterpret) {
        // 关闭AI解释：直接以叫品本身作为含义，不调用API（加快叫牌速度）
        appendBidHistory({
          position: currentBidder,
          hand: hands[currentBidder],
          biddingSequence: biddingStr,
          result: { bid: bid, meaning: bid },
          timestamp: makeBidTimestamp()
        })
      } else {
        // 没有自定义含义，调用API获取（传递数组，后端处理格式）
        setCurrentBiddingPosition(currentBidder)
        try {
          const bidHistory = aiBiddingHistoryRef.current.map(record => {
            const bidPrefix = `${record.result.bid}：`
            const meaning = record.result.meaning?.startsWith(bidPrefix)
              ? record.result.meaning.slice(bidPrefix.length)
              : (record.result.meaning || '')
            return `(${record.position})${record.result.bid}：${meaning}`
          }).join('\n')
          const result = await humanBid(biddingSequence, currentBidder, bid, dealSystem, bidHistory, bidSystem)
          
          appendBidHistory({
            position: currentBidder,
            hand: hands[currentBidder],
            biddingSequence: biddingStr,
            result: { 
              bid: result.bid, 
              meaning: result.meaning,
              full_output: result.full_output
            },
            timestamp: makeBidTimestamp()
          })
        } catch (err) {
          console.error('获取叫品含义失败:', err)
          appendBidHistory({
            position: currentBidder,
            hand: hands[currentBidder],
            biddingSequence: biddingStr,
            result: { 
              bid: bid, 
              meaning: '获取叫品含义失败',
              full_output: {}
            },
            timestamp: makeBidTimestamp()
          })
        } finally {
          setCurrentBiddingPosition(null)
        }
      }
      } finally {
        humanBidInFlightRef.current = false
      }
    }
    
    const newBid = {
      position: currentBidder,
      bid: bid
    }
    const newSequence = [...biddingSequence, newBid]
    
    // 计算下一个叫牌者
    const currentIndex = BRIDGE_POSITIONS.indexOf(currentBidder)
    const nextIndex = (currentIndex + 1) % 4
    const nextBidder = BRIDGE_POSITIONS[nextIndex]

    // 根据游戏模式判断是否需要为对方阵营添加自动pass
    if (gameMode === 'pair') {
      // 双人模式：南北 vs 东西，对方自动pass
      const humanPair = practiceDirection === 'NS' ? ['南', '北'] : ['东', '西']
      const isHumanTeam = humanPair.includes(currentBidder)
      const isNextHumanTeam = humanPair.includes(nextBidder)
      
      if (isHumanTeam !== isNextHumanTeam) {
        // 下一个是对方阵营，自动pass — 记录到 aiBiddingHistory
        const passBid = {
          position: nextBidder,
          bid: 'pass'
        }
        newSequence.push(passBid)
        const passBiddingStr = newSequence.map(b => `(${b.position})${b.bid}`).join('-')
        const autoPassRecord = {
          position: nextBidder,
          hand: hands[nextBidder],
          biddingSequence: passBiddingStr,
          // 标记：双人模式对方自动pass（右侧详情面板过滤，保持与四人叫牌一致）
          auto: true,
          result: { bid: 'pass', meaning: '双人模式对方自动pass' },
          timestamp: makeBidTimestamp()
        }
        // 用 appendBidHistory（ref 同步累积）而非闭包直接赋值：
        // 原代码闭包 aiBiddingHistory 不含本次刚追加的真实叫牌记录，
        // 直接赋值会覆盖掉它（历史只剩自动pass）——双人面板"只显示跳过信息"的根因
        const updatedHistory = appendBidHistory(autoPassRecord)

        // 继续计算下一个
        const nextNextIndex = (nextIndex + 1) % 4
        const nextNextBidder = BRIDGE_POSITIONS[nextNextIndex]

        setBiddingSequence(newSequence)
        setCurrentBidder(nextNextBidder)

        // 保存叫牌快照（双人模式自动pass）
        const snapshotPair = {
          biddingSequence: newSequence,
          currentBidder: nextNextBidder,
          aiBiddingHistory: [...updatedHistory],
        }
        const newHistoryPair = historyIndex >= 0 
          ? biddingHistory.slice(0, historyIndex + 1) 
          : biddingHistory
        setBiddingHistory([...newHistoryPair, snapshotPair])
        setHistoryIndex(newHistoryPair.length)
        
        return
      }
    }

    setBiddingSequence(newSequence)
    setCurrentBidder(nextBidder)
    
    // 保存叫牌快照（aiBiddingHistory 用 ref 取最新，避免漏掉刚追加的本次叫牌）
    const snapshot = {
      biddingSequence: newSequence,
      currentBidder: nextBidder,
      aiBiddingHistory: [...aiBiddingHistoryRef.current],
    }
    const newHistory = historyIndex >= 0 
      ? biddingHistory.slice(0, historyIndex + 1) 
      : biddingHistory
    setBiddingHistory([...newHistory, snapshot])
    setHistoryIndex(newHistory.length)
    
    // 四人模式：检查搭档两人是否相继pass（中间只有对方的一次叫牌或pass）
    // 前提：必须已有实质性叫牌（第一个实质性叫牌之前的pass不算）
    if (gameMode === 'four' && bid === 'pass') {
      // 检查是否已有实质性叫牌
      const hasRealBid = biddingSequence.some(b => b.bid !== 'pass')
      if (!hasRealBid) {
        return
      }
      
      // 搭档关系
      const partnerships = { '南': '北', '北': '南', '东': '西', '西': '东' }
      
      // 找到当前叫牌者的搭档
      const partner = partnerships[currentBidder]
      
      // 找到第一个实质性叫牌的位置
      let firstRealBidIndex = -1
      for (let i = 0; i < newSequence.length; i++) {
        if (newSequence[i].bid !== 'pass') {
          firstRealBidIndex = i
          break
        }
      }
      
      // 在叫牌序列中找搭档最近一次pass的位置（必须在第一个实质性叫牌之后）
      let partnerPassIndex = -1
      for (let i = newSequence.length - 2; i >= 0; i--) {
        if (i < firstRealBidIndex) continue  // 跳过第一个实质性叫牌之前的pass
        if (newSequence[i].position === partner && newSequence[i].bid === 'pass') {
          partnerPassIndex = i
          break
        }
      }
      
      // 如果搭档pass过，检查中间是否只有对方的叫牌
      if (partnerPassIndex !== -1) {
        // 从搭档pass到当前pass，中间应该只有一次叫牌（对方的）
        const bidsBetween = newSequence.slice(partnerPassIndex + 1, -1)
        if (bidsBetween.length === 1) {
          const middleBid = bidsBetween[0]
          // 检查中间的叫牌是否来自对方
          if (partnerships[middleBid.position] !== partner) {
            // 相继pass成立，标记需要自动pass的AI位置
            const currentIsAI = positionRoles[currentBidder] === 'ai'
            const partnerIsAI = positionRoles[partner] === 'ai'
            
            const positionsToMark = []
            if (currentIsAI) {
              positionsToMark.push(currentBidder)
            }
            if (partnerIsAI) {
              positionsToMark.push(partner)
            }
            
            if (positionsToMark.length > 0) {
              console.log(`搭档${currentBidder}和${partner}相继pass，AI位置${positionsToMark.join('、')}后续自动pass`)
              setPassedAIPositions(prev => {
                const newSet = new Set(prev)
                positionsToMark.forEach(pos => newSet.add(pos))
                return newSet
              })
            }
          }
        }
      }
    }
  }, [positionRoles, currentBidder, biddingStarted, biddingSequence, customBidMeaning, humanBidInterpret, hands, dealSystem, bidSystem, gameMode, practiceDirection, historyIndex, biddingHistory, appendBidHistory, makeBidTimestamp, setBiddingStarted, setCustomBidMeaning, setCurrentBiddingPosition, setBiddingSequence, setCurrentBidder, setBiddingHistory, setHistoryIndex, setPassedAIPositions])

  // 检查AI位置是否需要自动pass
  const shouldAIAutoPass = (position) => {
    return passedAIPositions.has(position)
  }

  // 调用AI叫牌
  const callAIBid = async () => {
    if (!hands || !currentBidder || isBiddingComplete()) return
    
    // 检查是否停止叫牌
    if (stopBidding) return
    
    // 检查是否是人类玩家的回合
    const isHumanTurn = positionRoles && positionRoles[currentBidder] === 'human'
    if (isHumanTurn) return
    
    // 检查AI位置是否需要自动pass
    if (gameMode === 'four' && shouldAIAutoPass(currentBidder)) {
      console.log(`${currentBidder}家因搭档相继pass，自动pass`)
      appendBidHistory({
        position: currentBidder,
        hand: hands[currentBidder],
        biddingSequence: biddingSequence.map(b => `(${b.position})${b.bid}`).join('-'),
        result: { bid: 'pass', meaning: '搭档已相继pass，不再参与叫牌' },
        timestamp: makeBidTimestamp()
      })
      addBid('pass')
      return
    }
    
    setCurrentBiddingPosition(currentBidder)
    setAiThinking(true)
    // P1 修复：支持"暂停"中止在途请求（toggleStopBidding 会 abort）
    const controller = new AbortController()
    bidAbortRef.current = controller
    try {
      // 用于显示的字符串
      const biddingStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-') + (biddingSequence.length > 0 ? '-' : '')
      
      // 构建累积的叫牌历史（与终端版格式一致）
      const bidHistory = aiBiddingHistory.map(record => {
        // 含义可能已包含 "叫品：" 前缀（JF匹配），先去重再统一添加
        const bidPrefix = `${record.result.bid}：`
        const meaning = record.result.meaning?.startsWith(bidPrefix)
          ? record.result.meaning.slice(bidPrefix.length)
          : (record.result.meaning || '')
        return `(${record.position})${record.result.bid}：${meaning}`
      }).join('\n')
      
      // 获取当前叫牌者的手牌
      const currentHand = hands[currentBidder]
      
      console.log(`AI叫牌: ${currentBidder}家, 手牌:`, currentHand, '叫牌序列:', biddingStr, '叫牌历史:', bidHistory)
      
      // 传递数组，后端处理格式
      const bm = parseModelValue(fallbackModel)
      const aiCallStart = Date.now()
      setAiProgress(null)
      const result = await aiBid(currentHand, biddingSequence, currentBidder, dealSystem, bidHistory, useFallback, bm.model, 'deepseek', bm.reasoning, controller.signal, (msg) => setAiProgress(msg), bidSystem)
      if (controller.signal.aborted) {
        // 用户已暂停，丢弃本次结果
        console.log('[AI叫牌] 用户已暂停，丢弃本次结果')
        return
      }
      const aiCallElapsed = Date.now() - aiCallStart
      
      // 更新useFallback状态
      if (result.use_fallback !== undefined) {
        setUseFallback(result.use_fallback)
      }

      console.log(`AI叫牌结果: ${currentBidder}家, 叫品:`, result.bid, '含义:', result.meaning)

      // 合规性检查失败：后端返回 暂停叫牌 标记时，停止自动叫牌等待用户处理
      if (result.full_output?.暂停叫牌) {
        setStopBidding(true)
        appendBidHistory({
          position: currentBidder,
          hand: currentHand,
          biddingSequence: biddingStr,
          result: { ...result, bid: 'pass', meaning: result.meaning || '[合规性错误] 已暂停叫牌等待处理' },
          timestamp: makeBidTimestamp(aiCallElapsed)
        })
        addBid('pass')
        return
      }

      // 保存AI叫牌历史记录
      appendBidHistory({
        position: currentBidder,
        hand: currentHand,
        biddingSequence: biddingStr,
        result: result,
        timestamp: makeBidTimestamp(aiCallElapsed)
      })

      // 添加AI叫牌
      addBid(result.bid)
    } catch (err) {
      if (err.name === 'CanceledError' || err.name === 'AbortError' || controller.signal.aborted) {
        // 用户主动暂停：不报错、不落 pass（stopBidding 已由暂停按钮置位）
        console.log('[AI叫牌] 请求已被用户中止')
        return
      }
      console.error('AI叫牌失败:', err)
      // P0-4 修复：不再静默自动 pass——提示错误并停止自动叫牌，
      // 用户可点击"继续叫牌"重试（toggleStopBidding 会重新触发 AI 叫牌）
      const errMsg = err.response?.data?.detail || err.message || '未知错误'
      setError(`AI叫牌失败: ${errMsg}（已停止自动叫牌，可点击"继续叫牌"重试）`)
      setStopBidding(true)
    } finally {
      if (bidAbortRef.current === controller) {
        bidAbortRef.current = null
      }
      setAiThinking(false)
      setAiProgress(null)
      setCurrentBiddingPosition(null)
    }
  }

  // 获取约定片段（按叫牌体系取JF或新睿）
  const getJFSuggestion = async () => {
    if (!hands || !currentBidder || isBiddingComplete()) return
    
    setSuggestionLoading(true)
    try {
      // 构建叫牌序列字符串
      const biddingStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-')
      
      // 调用分析API获取约定片段（随叫牌体系切换JF/新睿）
      const result = await analyzeBidding(biddingStr, currentBidder, dealSystem, bidSystem)
      
      setBidSuggestion({
        keyword: result.keyword,
        content: result.content,
        bidSystem,
      })
    } catch (err) {
      console.error('获取JF约定片段失败:', err)
      setBidSuggestion(null)
    } finally {
      setSuggestionLoading(false)
    }
  }

  // 当currentBidder变化时，检查是否需要调用AI叫牌或获取JF约定片段
  useEffect(() => {
    if (!hands || aiThinking) return
    
    // 叫牌已结束，不再处理
    if (isBiddingComplete()) return
    
    // 检查是否需要等待人类叫牌
    const isHumanTurn = positionRoles && positionRoles[currentBidder] === 'human'
    
    // 四人模式下，如果AI位置需要自动pass
    if (gameMode === 'four' && shouldAIAutoPass(currentBidder) && !isHumanTurn) {
      callAIBid()
      return
    }
    
    // 人类玩家回合时，获取JF约定片段并自动切换到叫牌控制面板
    if (isHumanTurn) {
      getJFSuggestion()
    }

    // AI叫牌逻辑
    if (!isHumanTurn && !stopBidding) {
      // AI回合
      const hasHumanPosition = positionRoles && Object.values(positionRoles).some(r => r === 'human')
      if (!hasHumanPosition) {
        // 观察模式：需要点击开始叫牌按钮
        if (biddingStarted) {
          callAIBid()
        }
      } else {
        // 有人类参与
        // 如果人类不是第一个叫牌，需要点击开始叫牌按钮
        // 如果人类是第一个叫牌，人类叫牌后biddingStarted会被设置为true
        if (biddingStarted) {
          callAIBid()
        }
      }
    }
  }, [currentBidder, positionRoles, hands, aiThinking, biddingSequence, biddingStarted, stopBidding, passedAIPositions])

  // 叫牌进度草稿自动保存 —— 每次叫牌序列变化时持久化到 localStorage
  useEffect(() => {
    // 只在叫牌进行中保存，debounce 500ms
    if (!biddingSequence || biddingSequence.length === 0) return
    if (isBiddingComplete()) return

    if (draftSaveTimerRef.current) {
      clearTimeout(draftSaveTimerRef.current)
    }
    draftSaveTimerRef.current = setTimeout(() => {
      const slimHistory = aiBiddingHistory.map(r => ({
        ...r,
        result: { bid: r.result.bid, meaning: r.result.meaning },
      }))
      const draft = {
        hands,
        dealer,
        gameMode,
        practiceDirection,
        positionRoles,
        dealSystem,
        dealMode,
        biddingSequence,
        currentBidder,
        aiBiddingHistory: slimHistory,
        biddingHistory,
        historyIndex,
        biddingStarted,
        stopBidding,
        passedAIPositions: Array.from(passedAIPositions),
        biddingStartTime,
        timestamp: Date.now(),
      }
      try {
        localStorage.setItem(BIDDING_DRAFT_KEY, JSON.stringify(draft))
      } catch (e) {
        console.warn('保存叫牌草稿失败:', e)
      }
    }, 500)

    return () => {
      if (draftSaveTimerRef.current) {
        clearTimeout(draftSaveTimerRef.current)
      }
    }
  }, [biddingSequence, currentBidder, aiBiddingHistory, biddingHistory, historyIndex, biddingStarted, stopBidding, passedAIPositions])






  // 确定最终定约
  const getFinalContract = () => {
    if (!isBiddingComplete() || biddingSequence.length === 0) return null

    // 找到最后一个非pass的叫品
    const nonPassBids = biddingSequence.filter(b => b.bid !== 'pass')
    if (nonPassBids.length === 0) return null

    const lastBid = nonPassBids[nonPassBids.length - 1]
    const bid = lastBid.bid

    // 解析叫品
    let level = 0
    let suit = ''
    let isDouble = false
    let isRedouble = false
    // 定约方位置：对于加倍(X)，定约方是被加倍方而非加倍方
    // 对于再加倍(XX)和普通叫品，定约方就是最后一个叫牌方
    let contractPosition = lastBid.position

    if (bid === 'X') {
      // 找到被加倍的叫品
      const targetBids = nonPassBids.slice(0, -1).filter(b => b.bid !== 'X' && b.bid !== 'XX')
      if (targetBids.length === 0) return null
      const targetBid = targetBids[targetBids.length - 1]
      level = parseInt(targetBid.bid[0])
      suit = targetBid.bid.substring(1)
      isDouble = true
      contractPosition = targetBid.position  // 定约方是被加倍方，不是加倍方
    } else if (bid === 'XX') {
      // 找到被再加倍的叫品
      const targetBids = nonPassBids.slice(0, -1).filter(b => b.bid === 'X')
      if (targetBids.length === 0) return null
      const doubleBid = targetBids[targetBids.length - 1]
      const originalBids = nonPassBids.slice(0, nonPassBids.indexOf(doubleBid)).filter(b => b.bid !== 'X' && b.bid !== 'XX')
      if (originalBids.length === 0) return null
      const originalBid = originalBids[originalBids.length - 1]
      level = parseInt(originalBid.bid[0])
      suit = originalBid.bid.substring(1)
      isDouble = true
      isRedouble = true
      // 再加倍方就是定约方（只有被加倍方才能再加倍），contractPosition 保持 lastBid.position
    } else {
      // 普通叫品
      level = parseInt(bid[0])
      suit = bid.substring(1)
      // contractPosition 保持 lastBid.position
    }

    // 确定定约方（叫牌者所在的一方）
    const partnership = ['南', '北'].includes(contractPosition) ? '南北' : '东西'

    // 确定庄家：定约方中第一个叫出该花色的人
    const partnershipPositions = partnership === '南北' ? ['南', '北'] : ['东', '西']
    let declarer = contractPosition
    for (const bidItem of biddingSequence) {
      if (partnershipPositions.includes(bidItem.position) && bidItem.bid.includes(suit) && bidItem.bid !== 'pass' && bidItem.bid !== 'X' && bidItem.bid !== 'XX') {
        declarer = bidItem.position
        break
      }
    }

    return {
      level,
      suit,
      isDouble,
      isRedouble,
      declarer,
      partnership,
      bid: bid
    }
  }

  const finalContract = useMemo(() => getFinalContract(), [biddingSequence])

  // 叫牌结束时自动保存记录
  useEffect(() => {
    if (isBiddingComplete() && biddingSequence.length > 0 && hands && !isLoadingRecordRef.current) {
      console.log('[自动保存] 叫牌完成，准备保存记录');
      clearBiddingDraft() // 叫牌完成，清除草稿
      // 计算总时间
      if (biddingStartTime) {
        const totalTime = Math.round((Date.now() - biddingStartTime) / 1000)
        setBiddingTotalTime(totalTime)
      }
      
      const finalContract = getFinalContract()
      const record = {
        id: Date.now().toString(),
        timestamp: new Date().toLocaleString(),
        type: 'bidding_complete',
        sourceRecordId: currentRecordId || undefined,
        board: {
          hands: hands,
          bidding_sequence: biddingSequence,
          contract: finalContract,
          dealer: dealer,
          game_mode: gameMode,
          practice_direction: practiceDirection,
          position_roles: positionRoles,
          opening_lead: imageOpeningLead || undefined,
        },
        bidding: {
          ai_bidding_history: trimBiddingHistory(aiBiddingHistory),
          deal_system: dealSystem,
        },
        play: null,
        note: ''
      }
      saveBridgeRecord(record)
      console.log('[自动保存] 叫牌记录已调用保存, id:', record.id)
      // 如果之前没有记录ID，保存后设置当前记录ID
      if (!currentRecordId) {
        setCurrentRecordId(record.id)
      }
      
      // 获取更多输出格式
      fetchOutputFormats()
    }
  }, [biddingSequence, hands, dealer])
  
  // 获取更多输出格式
  const fetchOutputFormats = async () => {
    if (!hands || biddingSequence.length === 0) return
    
    setOutputFormatsLoading(true)
    try {
      const biddingStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-')
      console.log('[DEBUG] 获取输出格式, biddingStr:', biddingStr, 'dealer:', dealer, 'gameMode:', gameMode)
      const result = await getOutputFormats(hands, biddingStr, dealer, gameMode, positionRoles, imageOpeningLead)
      console.log('[DEBUG] 输出格式结果:', result)
      setOutputFormats(result)
    } catch (err) {
      console.error('获取输出格式失败:', err)
    } finally {
      setOutputFormatsLoading(false)
    }
  }

  // 检验定约 - 调用Deep Finesse
  const handleAnalyzeContract = useCallback(async () => {
    if (!outputFormats?.deep_finesse) return

    setAnalyzeLoading(true)
    setAnalyzeResult(null)
    try {
      const result = await analyzeContract(outputFormats.deep_finesse)
      setAnalyzeResult(result)
      if (!result.success) {
        alert(`检验定约失败: ${result.error}`)
      }
    } catch (err) {
      console.error('检验定约失败:', err)
      alert('检验定约失败，请检查Deep Finesse是否正确安装')
    } finally {
      setAnalyzeLoading(false)
    }
  }, [outputFormats?.deep_finesse, setAnalyzeLoading, setAnalyzeResult])

  // 双明手分析（P1-8：手牌未变直接复用结果缓存；支持 AbortController 取消）
  const lastDDHandsKeyRef = useRef(null)
  const ddAbortRef = useRef(null)
  const handleDoubleDummy = async () => {
    if (!hands) return

    const handsKey = JSON.stringify(hands)
    if (lastDDHandsKeyRef.current === handsKey && doubleDummyResult) return

    if (ddAbortRef.current) ddAbortRef.current.abort()
    const controller = new AbortController()
    ddAbortRef.current = controller

    setDoubleDummyLoading(true)
    try {
      const result = await doubleDummyAnalysis(hands, controller.signal)
      if (result.success) {
        setDoubleDummyResult(result.table_data)
        lastDDHandsKeyRef.current = handsKey
      } else {
        alert(`双明手分析失败: ${result.error}`)
      }
    } catch (err) {
      if (err?.name === 'CanceledError' || err?.name === 'AbortError') return
      console.error('双明手分析失败:', err)
      alert('双明手分析失败，请检查endplay是否正确安装')
    } finally {
      if (ddAbortRef.current === controller) {
        setDoubleDummyLoading(false)
        ddAbortRef.current = null
      }
    }
  }

  // P1-8：取消双明手分析（中止在途请求并回到原视图）
  const cancelDoubleDummy = useCallback(() => {
    if (ddAbortRef.current) {
      ddAbortRef.current.abort()
      ddAbortRef.current = null
    }
    setDoubleDummyLoading(false)
    setShowDoubleDummy(false)
  }, [setDoubleDummyLoading, setShowDoubleDummy])

  // 切换显示双明手结果
  const toggleDoubleDummy = (checked) => {
    setShowDoubleDummy(checked)
    if (checked && hands) {
      handleDoubleDummy()
    }
  }

  // ==================== 打牌相关函数 ====================

  // 统一复盘/重打初始化：playInit + 回放 keepCount 张牌
  // keepCount: 0=重新打牌, N=倒回到第N张, 'all'=全部回放
  const replayInitAndPlay = async (keepCount) => {
    const savedState = loadedPlayRecord?.playState
    if (!savedState?.contract) return { error: '无打牌记录' }

    const contract = savedState.contract

    // 构建叫牌字符串（三方共用）
    let biddingStr = null, seqStr = '', meaningLines = ''
    if (biddingSequence.length > 0) {
      seqStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-')
      meaningLines = aiBiddingHistory
        .filter(r => r.result?.meaning)
        .map(formatBidMeaningLine)
        .join('\n')
      biddingStr = meaningLines
        ? `${seqStr}\n\n叫牌含义:\n${meaningLines}`
        : seqStr
    }

    // 收集所有已出牌（按顺序）
    const allPlayed = []
    for (const t of (savedState.tricks || [])) {
      for (const [pos, card] of (t.cards || [])) allPlayed.push({ pos, card })
    }
    for (const [pos, card] of (savedState.current_trick?.cards || [])) allPlayed.push({ pos, card })

    const actualKeep = keepCount === 'all' ? allPlayed.length : Math.max(0, Math.min(keepCount, allPlayed.length))

    // 计算保留的完整墩数和部分墩牌数
    let completedTricksToKeep = 0, cardsInPartialTrick = 0, accum = 0
    for (let i = 0; i < (savedState.tricks || []).length; i++) {
      const trickLen = (savedState.tricks[i].cards || []).length
      if (accum + trickLen <= actualKeep) { completedTricksToKeep++; accum += trickLen }
      else { cardsInPartialTrick = actualKeep - accum; break }
    }
    if (cardsInPartialTrick === 0 && accum < actualKeep) cardsInPartialTrick = actualKeep - accum

    // playInit
    const initResult = await playInit(
      hands,
      `${contract.level}${contract.suit}`,
      contract.declarer,
      positionRoles,
      contract.doubled || contract.isDouble || false,
      contract.redoubled || contract.isRedouble || false,
      biddingStr,
      seqStr,
      meaningLines,
      vulnerability,
      bidSystem
    )
    if (!initResult.success) return { error: initResult.error }

    // 完整复盘（回放至整副牌结束）：记录本身就是权威数据，按记录直接渲染，
    // 不依赖逐张后端合法性回放。实战模拟中对手两家是后期手工输入，早期在缺牌信息下
    // 产生的出牌顺序可能与最终整副牌不一致，逐张校验会误报“回放失败”。
    const savedPhase = savedState.phase
    const isFullReview = keepCount === 'all' && actualKeep >= allPlayed.length && savedPhase === 'complete'

    // 回放前 actualKeep 张牌（P1-9：显示 N/M 进度，统计失败张数）
    let lastReplayState = initResult.state
    let replayFailed = 0
    if (isFullReview) {
      // 完整复盘：跳过逐张后端校验，直接用记录构建展示态
      lastReplayState = null
    } else if (actualKeep > 0) {
      setReplayProgress({ current: 0, total: actualKeep })
      for (let i = 0; i < actualKeep; i++) {
        const { pos, card } = allPlayed[i]
        setReplayProgress({ current: i + 1, total: actualKeep })
        try {
          const reply = await playCard(pos, card)
          if (reply?.success) lastReplayState = reply.state
          else replayFailed++
        } catch (e) {
          replayFailed++
          console.warn('回放出牌失败:', pos, card, e)
        }
      }
      if (replayFailed > 0) {
        setWarning(`回放完成，但 ${replayFailed}/${actualKeep} 张牌回放失败，牌局状态可能与原记录不一致`)
      }
    }

    // 构建截断后的 playState
    const keptTricks = (savedState.tricks || []).slice(0, completedTricksToKeep)
    // P2 修复：部分墩可能位于 current_trick（进行中记录），tricks 取完时从 current_trick 取
    const partialSource = completedTricksToKeep < (savedState.tricks || []).length
      ? (savedState.tricks?.[completedTricksToKeep]?.cards || [])
      : (savedState.current_trick?.cards || [])
    const partialCards = cardsInPartialTrick > 0
      ? partialSource.slice(0, cardsInPartialTrick)
      : []
    const isLead = actualKeep === 0
    const allReplayed = actualKeep >= allPlayed.length

    // 展示用四家手牌：优先用完整回放得到的后端状态；否则从已载入的整副手牌重建
    const suitSym = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' }
    const buildPlayHands = (h) => {
      const out = {}
      for (const pos of ['北', '南', '东', '西']) {
        const hd = h?.[pos] || {}
        const cards = []
        for (const sk of ['spades', 'hearts', 'diamonds', 'clubs']) {
          for (const r of String(hd[sk] || '')) cards.push({ suit: suitSym[sk], rank: r })
        }
        out[pos] = cards
      }
      return out
    }
    const displayHands = lastReplayState?.hands || buildPlayHands(hands)
    const calcDecl = () => keptTricks.filter(t =>
      t.winner === contract.declarer || t.winner === savedState.dummy).length
    const calcDef = () => keptTricks.filter(t =>
      t.winner && t.winner !== contract.declarer && t.winner !== savedState.dummy).length
    const declTricks = lastReplayState
      ? (lastReplayState.declarer_tricks ?? calcDecl())
      : (savedState.declarer_tricks ?? calcDecl())
    const defTricks = lastReplayState
      ? (lastReplayState.defender_tricks ?? calcDef())
      : (savedState.defender_tricks ?? calcDef())

    const truncatedState = {
      ...(lastReplayState || savedState),
      hands: displayHands,
      tricks: keptTricks,
      current_trick: partialCards.length > 0
        ? { cards: partialCards, leader: partialCards[0]?.[0] || null, trump: contract.suit || null }
        : { cards: [], leader: null, trump: contract.suit || null },
      current_player: lastReplayState?.current_player ?? null,
      phase: allReplayed ? savedPhase : (isLead ? 'lead' : 'playing'),
      declarer_tricks: declTricks,
      defender_tricks: defTricks,
    }

    // 裁剪 aiPlayHistory
    let trimmedHistory = []
    if (loadedPlayRecord.aiPlayHistory?.length > 0) {
      const aiPositions = new Set(
        Object.entries(loadedPlayRecord.position_roles || positionRoles)
          .filter(([, role]) => role === 'ai')
          .map(([pos]) => pos)
      )
      let historyIdx = 0
      for (let i = 0; i < actualKeep; i++) {
        const pos = allPlayed[i].pos
        if (aiPositions.has(pos) && historyIdx < loadedPlayRecord.aiPlayHistory.length) {
          trimmedHistory.push(loadedPlayRecord.aiPlayHistory[historyIdx])
          historyIdx++
        }
      }
    }

    return { success: true, allPlayed, actualKeep, truncatedState, trimmedHistory, seqStr, meaningLines }
  }

  // ── 统一回放入口：导入查看 / 倒回 / 重新打牌 共用 ──
  // keepCount: 'all'=全部回放(查看), 0=全新开始(重打), N=回放到第N张(倒回)
  const startReplay = async (keepCount) => {
    const savedState = loadedPlayRecord?.playState
    if (!savedState?.contract) return

    setAiThinking(false) // 复盘/回放前清除残留思考态（完成态旋转不停问题）
    setPlayLoading(true)
    setError(null)
    try {
      const result = await replayInitAndPlay(keepCount)
      if (result?.error) { console.error('回放失败:', result.error); return }

      const isFresh = (keepCount === 0)

      setPlayState(result.truncatedState)
      setAiPlayHistory(isFresh ? [] : result.trimmedHistory)
      setLastCompletedTrick(null)
      setShowPlayPanel(true)
      // 只重新打牌(fresh)：先停在初始态，等用户点“开始打牌”后再启动（四家AI也不自动开始）；
      // 复盘(keepCount>0)：直接进入回放态
      setIsPlayPaused(isFresh ? false : true)
      setPlayInitiated(isFresh ? false : true)
      setPlayStarted(isFresh ? false : result.actualKeep > 0)
      setReviewCursor(null)
      if (isFresh) {
        setLoadedPlayRecord(null)
        setCurrentRecordId(null)
        setSelectedPlayRecord(null)
        setPlayCenterView('play')
      }
    } catch (err) {
      console.error('回放失败:', err)
    } finally {
      setPlayLoading(false)
      setReplayProgress(null)
    }
  }

  // 开始打牌
  const handleStartPlay = async (chosenMode) => {
    if (loadedPlayRecord) {
      const savedState = loadedPlayRecord.playState
      const totalCards = (savedState.tricks || []).reduce((s, t) => s + (t.cards?.length || 0), 0)
        + (savedState.current_trick?.cards?.length || 0)
      // 完成态记录：提供"复盘 / 只重新打牌"二选一；复盘才带 DD hint 数据，只重新打牌不带
      const isComplete = savedState.phase === 'complete'
      const mode = chosenMode || recordActionMode
      if (isComplete && !mode) {
        setRecordActionMode(null)
        setRecordActionDialogOpen(true)
        return
      }
      if (isComplete && mode === 'replay') {
        setRecordActionMode(null)
        await startReplay(0)
        return
      }
      setRecordActionMode(null)
      await startReplay('all')
      // 复盘：完成后停在全部已出位置，牌桌显示完整结果（最后一张也在桌上）
      setReviewCursor(totalCards)
      return
    }

    const contract = getFinalContract() || directPlayContractInfo

    // 始终弹出定约确认对话框，预填识别到的信息以便调整
    if (contract) {
      const suitLetter = { '♠': 'S', '♥': 'H', '♦': 'D', '♣': 'C', 'S': 'S', 'H': 'H', 'D': 'D', 'C': 'C', 'NT': 'NT' }[contract.suit] || contract.suit
      const contractStr = `${contract.level}${suitLetter}${contract.isDouble ? 'X' : ''}${contract.isRedouble ? 'XX' : ''}`
      setContractDialogForm({
        contractStr,
        declarer: contract.declarer,
        openingLead: imageOpeningLead || '',
        isDouble: contract.isDouble || false,
        isRedouble: contract.isRedouble || false,
      })
    } else {
      setContractDialogForm({ contractStr: '', declarer: '南', openingLead: imageOpeningLead || '', isDouble: false, isRedouble: false })
    }
    setContractDialogOpen(true)
    return
  }

  // 载入已完成牌局时的二选一确认
  const confirmRecordAction = (mode) => {
    setRecordActionDialogOpen(false)
    handleStartPlay(mode)
  }

  // 复盘：优先用当前刚打完成的牌局（内存 playState 已在），避免等后端落盘的时序窗口；否则从历史取
const handleReviewCompletedPlay = async () => {
    if (showPlayPanel && playState?.phase === 'complete') {
      const record = {
        id: currentRecordId || Date.now().toString(),
        timestamp: new Date().toLocaleString(),
        type: 'play_complete',
        sourceRecordId: currentRecordId || undefined,
        board: {
          hands,
          bidding_sequence: biddingSequence,
          contract: getFinalContract() || directPlayContractInfo,
          dealer,
          opening_lead: imageOpeningLead,
        },
        bidding: {
          ai_bidding_history: trimBiddingHistory(aiBiddingHistory),
          deal_system: dealSystem,
        },
        play: {
          tricks: playState.tricks,
          ai_play_history: trimPlayHistory(aiPlayHistory),
          declarer_tricks: playState.declarer_tricks,
          defender_tricks: playState.defender_tricks,
        },
      }
      setRecordActionMode('review')
      loadRecordToTable(record)
      return
    }

    const latest = [...bridgeRecords]
      .filter(r => r.type === 'play_complete' && r.play?.tricks)
      .sort((a, b) => String(b.id || 0).localeCompare(String(a.id || 0)))[0]
    if (!latest) {
      setError('没有可复盘的记录')
      return
    }
    // 列表项是轻量摘要，复盘需先从后端取完整记录
    const full = await fetchFullRecord(latest.id)
    if (!full) {
      setError('加载复盘记录失败')
      return
    }
    // 点“复盘”意图已明确，直接进入复盘，不再弹“复盘 / 只重新打牌”二选一对话框
    setRecordActionMode('review')
    loadRecordToTable(full)
  }

  const handleRewindToTrick = async (targetCardIdx) => {
    // targetCardIdx: 从第几张牌开始重打（新游标语义 = 已出牌数量 = 下一个出牌者的牌序号）
    // 即：保留前 targetCardIdx 张牌，从第 targetCardIdx 张开始重打
    const savedState = loadedPlayRecord?.playState
    if (!savedState?.contract) return
    // 收集所有已出牌（按顺序）
    const allPlayed = []
    for (const t of (savedState.tricks || [])) {
      for (const [pos, card] of (t.cards || [])) allPlayed.push({ pos, card })
    }
    for (const [pos, card] of (savedState.current_trick?.cards || [])) allPlayed.push({ pos, card })
    // targetCardIdx = 保留的牌数量（也是开始重打的牌序号）
    const keepCount = Math.max(0, Math.min(targetCardIdx, allPlayed.length))
    // 计算保留的牌分布在哪些完整墩 + 一个可能未满的当前墩
    let completedTricksToKeep = 0
    let cardsInPartialTrick = 0
    let accum = 0
    for (let i = 0; i < (savedState.tricks || []).length; i++) {
      const trickLen = (savedState.tricks[i].cards || []).length
      if (accum + trickLen <= keepCount) {
        completedTricksToKeep++
        accum += trickLen
      } else {
        cardsInPartialTrick = keepCount - accum
        break
      }
    }
    if (cardsInPartialTrick === 0 && accum < keepCount) {
      cardsInPartialTrick = keepCount - accum
    }
    setPlayLoading(true)
    setError(null)
    try {
      const contract = savedState.contract
      let biddingStr = null
      let meaningLines = ''
      let seqStr = ''
      if (biddingSequence.length > 0) {
        seqStr = biddingSequence.map(b => `(${b.position})${b.bid}`).join('-')
        meaningLines = aiBiddingHistory
          .filter(r => r.result?.meaning)
          .map(formatBidMeaningLine)
          .join('\n')
        biddingStr = meaningLines
          ? `${seqStr}\n\n叫牌含义:\n${meaningLines}`
          : seqStr
      }
      const initResult = await playInit(
        hands,
        `${contract.level}${contract.suit}`,
        contract.declarer,
        positionRoles,
        contract.doubled || contract.isDouble || false,
        contract.redoubled || contract.isRedouble || false,
        biddingStr,
        seqStr,
        meaningLines,
        vulnerability,
        bidSystem
      )
      if (!initResult.success) {
        console.error('重打初始化失败:', initResult.error)
        setPlayLoading(false)
        return
      }
      // 回放前 keepCount 张牌（完整墩 + 部分墩）（P1-9：显示 N/M 进度，统计失败张数）
      const cardsToReplay = allPlayed.slice(0, keepCount).map(p => ({ position: p.pos, card: p.card }))
      let lastReplayState = null
      let replayFailed = 0
      if (keepCount > 0) setReplayProgress({ current: 0, total: keepCount })
      for (const [ri, { position, card }] of cardsToReplay.entries()) {
        setReplayProgress({ current: ri + 1, total: keepCount })
        try {
          const replayResult = await playCard(position, card)
          if (replayResult?.success) lastReplayState = replayResult.state
          else replayFailed++
        } catch (e) {
          replayFailed++
          console.warn('重放出牌失败:', position, card, e)
        }
      }
      if (replayFailed > 0) {
        setWarning(`回放完成，但 ${replayFailed}/${keepCount} 张牌回放失败，牌局状态可能与原记录不一致`)
      }
      // 裁剪 aiPlayHistory：按实际回放的牌筛选 AI 位置
      let trimmedHistory = []
      if (loadedPlayRecord.aiPlayHistory?.length > 0) {
        const aiPositions = new Set(
          Object.entries(loadedPlayRecord.position_roles || positionRoles)
            .filter(([, role]) => role === 'ai')
            .map(([pos]) => pos)
        )
        let historyIdx = 0
        for (let i = 0; i < keepCount; i++) {
          const pos = allPlayed[i].pos
          if (aiPositions.has(pos) && historyIdx < loadedPlayRecord.aiPlayHistory.length) {
            trimmedHistory.push(loadedPlayRecord.aiPlayHistory[historyIdx])
            historyIdx++
          }
        }
      }
      // 构建截断后的 playState（使用后端回放后的真实状态，保证 hands/current_trick 等正确）
      const keptCompletedTricks = (savedState.tricks || []).slice(0, completedTricksToKeep)
      // P2 修复：部分墩可能位于 current_trick（进行中记录），tricks 取完时从 current_trick 取
      const partialTrickSource = completedTricksToKeep < (savedState.tricks || []).length
        ? (savedState.tricks?.[completedTricksToKeep]?.cards || [])
        : (savedState.current_trick?.cards || [])
      const partialTrickCards = cardsInPartialTrick > 0
        ? partialTrickSource.slice(0, cardsInPartialTrick)
        : []
      const truncatedState = lastReplayState
        ? {
            ...lastReplayState,
            tricks: keptCompletedTricks,
            current_trick: partialTrickCards.length > 0
              ? { cards: partialTrickCards, leader: partialTrickCards[0]?.[0] || null, trump: savedState.contract?.suit || null }
              : { cards: [], leader: null, trump: savedState.contract?.suit || null },
            phase: keepCount === 0 ? 'lead' : 'playing',
          }
        : {
            ...savedState,
            tricks: keptCompletedTricks,
            current_trick: partialTrickCards.length > 0
              ? { cards: partialTrickCards, leader: partialTrickCards[0]?.[0] || null, trump: savedState.contract?.suit || null }
              : { cards: [], leader: null, trump: savedState.contract?.suit || null },
            current_player: null,
            phase: keepCount === 0 ? 'lead' : 'playing',
            declarer_tricks: keptCompletedTricks
              .filter(t => t.winner === savedState.contract?.declarer || t.winner === savedState.dummy).length,
            defender_tricks: keptCompletedTricks
              .filter(t => t.winner && t.winner !== savedState.contract?.declarer && t.winner !== savedState.dummy).length,
          }
      setPlayState(truncatedState)
      setAiPlayHistory(trimmedHistory)
      setLastCompletedTrick(null)
      setShowPlayPanel(true)
      setIsPlayPaused(true)
      setPlayInitiated(true)
      setPlayStarted(keepCount > 0)
      setReviewCursor(null)
      setCurrentRecordId(null)
    } catch (err) {
      console.error('重打失败:', err)
    } finally {
      setPlayLoading(false)
      setReplayProgress(null)
    }
  }

  // 抽取公共打牌初始化逻辑（handleStartPlay / handleResetPlay / 直接打牌 共用）
  const doPlayInit = async (contract, biddingSeq, aiHistory) => {
    setPlayLoading(true)
    setError(null)
    setAiThinking(false) // 重新打牌/初始化时清除残留思考态（完成或中途单张直出后可能残留 true）
    setIsPlayPaused(false)
    setPlayStarted(false)
    setPlayInitiated(false)
    setShowPlayedCards(true)
    prevTricksCountRef.current = 0
    setLastCompletedTrick(null)
    setReviewCursor(null)
    setAiPlayHistory([])
    setSelectedPlayRecord(null)

    let biddingStr = null
    let meaningLines = ''
    let seqStr = ''
    if (biddingSeq.length > 0) {
      seqStr = biddingSeq.map(b => `(${b.position})${b.bid}`).join('-')
      meaningLines = aiHistory
        .filter(r => r.result?.meaning)
        .map(formatBidMeaningLine)
        .join('\n')
      biddingStr = meaningLines
        ? `${seqStr}\n\n叫牌含义:\n${meaningLines}`
        : seqStr
    }

    const playRoles = { ...positionRoles }

    try {
      const suitLetter = { '♠': 'S', '♥': 'H', '♦': 'D', '♣': 'C', 'S': 'S', 'H': 'H', 'D': 'D', 'C': 'C', 'NT': 'NT' }[contract.suit] || contract.suit
      const contractStr = `${contract.level}${suitLetter}`
      if (!contract.level || !contract.suit) {
        setError(`定约信息不完整: ${contractStr}，请检查识别结果`)
        setLoading(false)
        return
      }
      const result = await playInit(
        hands,
        contractStr,
        contract.declarer,
        playRoles,
        contract.isDouble || false,
        contract.isRedouble || false,
        biddingStr,
        seqStr,
        meaningLines,
        vulnerability,
        bidSystem
      )

      if (result.success) {
        setPlayState(result.state)
        setShowPlayPanel(true)
        // 保留imageOpeningLead，等用户点击"开始"后再打出
      } else {
        setError(result.error || '初始化打牌失败')
      }
    } catch (err) {
      console.error('初始化打牌失败:', err)
      setError('初始化打牌失败: ' + (err.response?.data?.detail || err.message))
    } finally {
      setPlayLoading(false)
    }
  }

  // 直接打牌：对话框确认，解析定约并调用 doPlayInit
  const handleContractDialogConfirm = async () => {
    const { contractStr, declarer, openingLead, isDouble, isRedouble } = contractDialogForm
    // 支持 4H、4HX、4HXX 三种格式，X/XX 由 toggle 按钮单独追踪
    const match = contractStr.trim().match(/^(\d)([SHDC]|NT)(X{1,2})?$/i)
    if (!match) {
      setError('无效定约格式，请输入如 4S、3NT、4HX 或 2SXX')
      return
    }
    const contract = {
      level: parseInt(match[1]),
      suit: match[2].toUpperCase(),
      declarer,
      isDouble: isDouble || false,
      isRedouble: isRedouble || false,
      partnership: ['南', '北'].includes(declarer) ? '南北' : '东西',
      bid: contractStr.trim(),
    }
    setDirectPlayContractInfo(contract)
    // 保存用户确认的首攻信息，供 handleBeginPlay 使用
    setImageOpeningLead(openingLead || null)
    setContractDialogOpen(false)
    // 传递截屏/识别得到的叫牌序列，确保后端能据此提取约束（避免DD显示"无约束随机采样"）
    await doPlayInit(contract, biddingSequence, aiBiddingHistory)
  }

  // 出牌
  // 出牌失败时回退乐观更新，重新拉取后端真实状态
  const reconcilePlayState = useCallback(async () => {
    try {
      const s = await getPlayState()
      if (s.success) setPlayState(s.state)
    } catch (err) {
      console.error('回退状态失败:', err)
    }
  }, [setPlayState])

  const handlePlayCard = useCallback(async (position, card) => {
    // P2-5 修复：出牌请求在途时忽略重复点击（连点两张 → 第二张被后端拒绝 → 桌面闪跳）
    if (playCardInFlightRef.current) return
    playCardInFlightRef.current = true
    aiPlayInFlightRef.current = true // v1.61：标记在途，直到后端确认（乐观更新窗口内挡住重复调度）
    const seqAtStart = undoSeqRef.current
    // 乐观更新：立即在桌面上显示点击的牌，避免等待后端DD计算造成延迟
    setPlayState(prev => {
      if (!prev || !prev.current_trick) return prev
      return {
        ...prev,
        current_trick: {
          ...prev.current_trick,
          cards: [...(prev.current_trick.cards || []), [position, card]],
        },
        hands: {
          ...prev.hands,
          [position]: (prev.hands?.[position] || []).filter(c => !(c.suit === card.suit && c.rank === card.rank)),
        },
      }
    })
    setPlayLoading(true)
    setError(null)

    try {
      const result = await playCard(position, card)

      // 撤销序号守卫：出牌在途期间用户点了撤销 → 丢弃本次响应，以后端撤销后的真实状态为准
      if (undoSeqRef.current !== seqAtStart) {
        await reconcilePlayState()
        return
      }

      if (result.success) {
        console.log('[DEBUG handlePlayCard] result.state.current_trick:', result.state.current_trick)
        setPlayState(result.state)
        setPlayStarted(true)
        // 人类出牌后取消暂停，让下家（AI或人类）自动衔接
        setIsPlayPaused(false)

        if (result.is_complete && result.result) {
          console.log('打牌结束:', result.result)
        }
      } else {
        setError(result.error || result.message || '出牌失败')
        // 出牌失败，回退乐观更新，恢复后端真实状态
        await reconcilePlayState()
      }
    } catch (err) {
      console.error('出牌失败:', err)
      setError('出牌失败: ' + (err.response?.data?.detail || err.message))
      // 出牌失败，回退乐观更新，恢复后端真实状态
      await reconcilePlayState()
    } finally {
      playCardInFlightRef.current = false
      aiPlayInFlightRef.current = false
      setPlayLoading(false)
    }
  }, [reconcilePlayState, setPlayState, setPlayLoading, setError, setPlayStarted, setIsPlayPaused])

  // 点击牌桌上的手牌直接出牌
  const handleHandCardClick = useCallback((suitSymbol, rank) => {
    if (!playState?.current_player) return
    handlePlayCard(playState.current_player, { suit: suitSymbol, rank })
  }, [playState?.current_player, handlePlayCard])

  // 人类手动输入牌张（无手牌数据时）
  const handleManualPlay = useCallback((position, cardStr) => {
    cardStr = cardStr.trim()
    // 解析格式: "♠A" / "S A" / "♠10" / "SA"
    let suit, rank
    const m2 = cardStr.match(/^(\S)([2-9TJQKA]|10)$/i)
    if (m2) {
      suit = m2[1]
      rank = m2[2].toUpperCase() === '10' ? 'T' : m2[2].toUpperCase()
    } else {
      const parts = cardStr.split(/\s+/)
      if (parts.length === 2) {
        suit = parts[0]
        rank = parts[1].toUpperCase() === '10' ? 'T' : parts[1].toUpperCase()
      }
    }
    if (!suit || !rank) {
      setError('无法解析牌张，请输入如 ♠A 或 S A')
      return
    }
    // 花色标准化
    const suitMap = { 'S': '♠', 'H': '♥', 'D': '♦', 'C': '♣' }
    suit = suitMap[suit.toUpperCase()] || suit
    handlePlayCard(position, { suit, rank })
  }, [setError, handlePlayCard])

  const handleSetPlayHand = useCallback(async (position, hand) => {
    setPlayLoading(true)
    try {
      const result = await setPlayHand(position, hand)
      if (result.success && result.state) {
        setPlayState(result.state)
        // 同步更新前端 hands 状态，避免 showInput 拦截手牌显示
        setHands(prev => ({ ...prev, [position]: hand }))
      } else {
        setError(result.error || '设置手牌失败')
      }
    } catch (err) {
      setError('设置手牌失败: ' + (err.response?.data?.detail || err.message))
    } finally {
      setPlayLoading(false)
    }
  }, [setPlayLoading, setPlayState, setHands, setError])

  // AI出牌
  const handleAIPlay = async () => {
    // 如果已有进行中的请求，先中止
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }
    const controller = new AbortController()
    abortControllerRef.current = controller
    aiPlayInFlightRef.current = true // v1.61：标记在途，直到后端确认（防 AI 回合重复调度）
    const seqAtStart = undoSeqRef.current

    setAiThinking(true)
    setAiProgress(null)
    setError(null)

    try {
      const pm = parseModelValue(playModel)
      const t0 = performance.now()
      const result = await aiPlay(pm.model, pm.reasoning, playEngine, ddSampleCount, controller.signal, switchCards, useLlmReview, ddScoringMode, (msg) => setAiProgress(msg))
      if (controller.signal.aborted) return
      // 撤销序号守卫：AI 出牌在途期间用户点了撤销 → 丢弃本次响应，以后端撤销后的真实状态为准
      if (undoSeqRef.current !== seqAtStart) {
        await reconcilePlayState()
        return
      }
      console.log('[AI Play] engine:', result.used_engine, 'elapsed:', result.elapsed_ms + 'ms', 'model:', result.used_model)
      console.log(`[AI Play] frontend_total=${Math.round(performance.now() - t0)}ms (engine=${result.elapsed_ms}ms, overhead=${Math.round(performance.now() - t0 - result.elapsed_ms)}ms)`)

      if (result.success) {
        const aiRecord = {
          position: playState?.current_player,
          card: result.card,
          reasoning: result.reasoning,
          follow_up: result.follow_up,
          full_output: result.full_output,
          prompt: result.prompt,
          used_model: result.used_model,
          used_engine: result.used_engine,
          elapsed_ms: result.elapsed_ms,
          timestamp: makeBidTimestamp(),
        }
        setAiPlayHistory(prev => [...prev, aiRecord])
        setPlayStarted(true)
        // 直接用 aiPlay 返回的 state 更新桌面，避免额外的 getPlayState 往返造成延迟
        if (result.state) {
          setPlayState(result.state)
        } else {
          const stateResult = await getPlayState()
          if (stateResult.success) {
            setPlayState(stateResult.state)
          }
        }
      } else {
        // P0-2 修复：引擎返回失败时暂停自动出牌（避免 aiThinking 自激无限重试烧预算），用户点击"继续"重试
        setError((result.error || 'AI出牌失败') + '（已暂停，点击"继续"重试）')
        setIsPlayPaused(true)
      }
    } catch (err) {
      if (err.name === 'CanceledError' || err.name === 'AbortError' || controller.signal.aborted) {
        console.log('[AI Play] 用户已暂停，忽略')
        return
      }
      console.error('AI出牌失败:', err)
      // P0-2 修复：失败后暂停自动出牌（打破 aiThinking 自激无限重试循环），
      // 连续失败不会反复烧掉引擎时间预算；用户点击"继续"后重试一次
      setError('AI出牌失败: ' + (err.response?.data?.detail || err.message) + '（已暂停，点击"继续"重试）')
      setIsPlayPaused(true)
    } finally {
      if (abortControllerRef.current === controller) {
        abortControllerRef.current = null
      }
      aiPlayInFlightRef.current = false
      setAiThinking(false)
    }
  }

  const handleResumePlay = () => {
    setIsPlayPaused(false)
    setLastCompletedTrick(null)
    setShowDoubleDummy(false)
    setSelectedPlayRecord(null)
    setReviewCursor(null)
  }

  // 将 "S5"/"HK" 等卡片字符串转换为 API 所需的 {suit, rank} 格式
  const parseCardStr = (cardStr) => {
    if (!cardStr) return null
    const suitMap = { S: '♠', H: '♥', D: '♦', C: '♣', '♠': '♠', '♥': '♥', '♦': '♦', '♣': '♣' }
    const match = cardStr.trim().match(/^([SHDC♠♥♦♣])([2-9TJQKA]|10)$/i)
    if (!match) return null
    return { suit: suitMap[match[1].toUpperCase()] || match[1], rank: match[2] }
  }

  // 开始打牌（从初始未开始状态进入打牌）
  const handleBeginPlay = async () => {
    // 如果有首攻信息（图片识别或用户输入），先打出首攻再启动AI
    if (imageOpeningLead) {
      // 支持英文冒号 ":" 和中文冒号 "：" 两种分隔符
      const parts = imageOpeningLead.split(/[:：]/)
      let leadPos, cardObj

      if (parts.length >= 2) {
        // 完整格式: "西:S5" 或 "西:DA"
        leadPos = parts[0].trim()
        cardObj = parseCardStr(parts.slice(1).join(':'))
      } else {
        // 只有牌张没有位置: "S5"、"DA"、"♠5" → 用当前应出牌人的位置
        cardObj = parseCardStr(imageOpeningLead.trim())
        if (cardObj) {
          // 首攻人就是当前回合的玩家（playState初始化后current_player=lead_player）
          leadPos = playState?.current_player
        }
      }

      if (leadPos && cardObj) {
        try {
          const playResult = await playCard(leadPos, cardObj)
          if (playResult.success) {
            setPlayState(playResult.state)
            setPlayStarted(true)
          } else {
            setError(playResult.error || '首攻出牌失败')
            return
          }
        } catch (e) {
          console.warn('首攻出牌失败:', e)
          setError('首攻出牌失败: ' + (e.response?.data?.detail || e.message))
          return
        }
        // 首攻打出后再启动AI自动出牌
        setPlayInitiated(true)
        setIsPlayPaused(false)
        return
      } else {
        // 解析失败，提示但不清除输入
        if (!cardObj) {
          setError(`首攻牌张无效: "${imageOpeningLead}"，请输入花色+牌面（如 S5、DA、♠K）或完整格式 西:S5`)
        } else {
          setError(`无法确定首攻人位置，请加上位置，如 西:${imageOpeningLead}`)
        }
        return
      }
    }
    // 没有首攻信息，正常开始
    setPlayInitiated(true)
    setIsPlayPaused(false)
  }

  // 暂停打牌（立即中止AI请求）
  const handlePausePlay = () => {
    setIsPlayPaused(true)
    // 修复：暂停同时清除思考态，立即停止旋转（否则 aiThinking 卡 true，暂停无效）
    setAiThinking(false)
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
      abortControllerRef.current = null
    }
  }

  // 撤销最近一次出牌
  const handleUndoPlay = async () => {
    try {
      // 记录撤销前的状态，用于判断撤销了谁出的牌
      const prevTrickCards = playState?.current_trick?.cards || []
      const prevLastTrick = playState?.tricks?.[playState.tricks.length - 1]
      const undoneCard = prevTrickCards.length > 0
        ? prevTrickCards[prevTrickCards.length - 1][1]
        : prevLastTrick?.cards?.[prevLastTrick.cards.length - 1]?.[1]

      const result = await undoPlay()
      if (result.success) {
        // 撤销序号递增：让在途的出牌/AI响应感知撤销已发生，丢弃过期状态
        undoSeqRef.current += 1
        // 中止在途 AI 出牌请求并清除思考态，防止响应回来覆盖撤销结果
        if (abortControllerRef.current) {
          abortControllerRef.current.abort()
          abortControllerRef.current = null
        }
        setAiThinking(false)
        const state = result.state
        setPlayState(state)
          setSelectedPlayRecord(null)

        // 撤销的牌是刚出的那张，出牌者现在是current_player（撤销后轮到他重新出牌）
        // 如果这张牌是AI出的，从aiPlayHistory中删除对应记录
        const undonePlayer = state.current_player
        // 修复：必须位置+牌张双匹配——撤销人类/快速通道出的牌时，
        // 只按位置匹配会误删同位置更早的AI记录（如12墩AI记录被13墩唯一牌撤销误删）
        setAiPlayHistory(prev => {
          if (prev.length > 0) {
            const lastRecord = prev[prev.length - 1]
            if (lastRecord.position === undonePlayer &&
                undoneCard &&
                lastRecord.card?.suit === undoneCard.suit &&
                lastRecord.card?.rank === undoneCard.rank) {
              return prev.slice(0, -1)
            }
          }
          return prev
        })
        
        // 同步更新墩数计数器，避免"一墩完成自动暂停"误触发
        const newTricksCount = state.tricks?.length || 0
        prevTricksCountRef.current = newTricksCount
        
        // 更新lastCompletedTrick以匹配撤销后的状态
        if (newTricksCount > 0) {
          setLastCompletedTrick(state.tricks[newTricksCount - 1])
        } else {
          setLastCompletedTrick(null)
        }
        
        // 判断撤销后是否还有已出牌
        const hasPlayedCards = newTricksCount > 0 || 
                               (state.current_trick?.cards && state.current_trick.cards.length > 0)
        if (!hasPlayedCards) {
          // 撤销到没有已出牌时，重置为未开始状态
          setPlayStarted(false)
          setPlayInitiated(false)
        } else {
          setPlayStarted(true)
        }
        
        // 撤销后暂停，让用户决定下一步
        setIsPlayPaused(true)
      } else {
        setError(result.error || result.message || '撤销失败')
      }
    } catch (err) {
      console.error('撤销出牌失败:', err)
      setError('撤销出牌失败')
    }
  }

  // 返回叫牌界面（放弃打牌过程和数据）
  const handleBackToBidding = () => {
    if (!window.confirm('确定要返回叫牌界面吗？\n\n当前的打牌过程和数据将被丢弃，但叫牌序列和手牌会保留。')) {
      return
    }
    setAiThinking(false) // 返回叫牌时清除残留思考态（停止旋转/计时）
    setPlayState(null)
    setAiPlayHistory([])
    setShowPlayPanel(false)
    setIsPlayPaused(false)
    setPlayInitiated(false)
    setPlayStarted(false)
    setLoadedPlayRecord(null)
    setSelectedPlayRecord(null)
    setReviewCursor(null)
    setLastCompletedTrick(null)
    console.log('[Play] 已返回叫牌界面，打牌数据已清除')
  }

  // 重新打牌（保持当前牌局和叫牌，重置打牌状态并重新初始化）
  const handleResetPlay = async () => {
    let contract = getFinalContract()
    if (!contract) contract = directPlayContractInfo
    if (!contract) {
      setError('无法确定定约')
      return
    }

    setResetOpeningLeadValue(imageOpeningLead || '')
    setResetOpeningLeadDialogOpen(true)
  }

  const doResetPlay = async (contract) => {
    if (loadedPlayRecord) {
      await startReplay(0)
    } else {
      await doPlayInit(contract, biddingSequence, aiBiddingHistory)
    }
  }

  const handleResetOpeningLeadConfirm = (action) => {
    setResetOpeningLeadDialogOpen(false)
    let contract = getFinalContract()
    if (!contract) contract = directPlayContractInfo

    if (action === 'keep') {
      // 保留当前首攻
    } else if (action === 'clear') {
      setImageOpeningLead(null)
    } else if (action === 'edit') {
      setImageOpeningLead(resetOpeningLeadValue || null)
    }
    doResetPlay(contract)
  }

  // 桌面点击已出牌，切换到对应的打牌细节
  const handlePlayCardClick = useCallback((position, card) => {
    const history = aiPlayHistoryRef.current
    if (!history || history.length === 0) return
    const found = history.find(record =>
      record.position === position &&
      record.card?.suit === card.suit &&
      record.card?.rank === card.rank
    )
    if (found) {
      setSelectedPlayRecord(found)
    }
  }, [setSelectedPlayRecord])

  // 前端计算当前玩家的合法出牌（与 PlayPanel.getPlayableCards 一致）
  const getLegalPlaysForPlayer = (position) => {
    const hand = playState?.hands?.[position] || []
    if (hand.length === 0) return []
    const trickCards = playState?.current_trick?.cards || []
    if (trickCards.length === 0) return hand
    const leadSuit = trickCards[0][1].suit
    const sameSuit = hand.filter(c => c.suit === leadSuit)
    return sameSuit.length > 0 ? sameSuit : hand
  }

  // 根据前端 positionRoles 计算当前回合是否为人类
  const isCurrentPlayerHuman = () => {
    if (!playState) return false
    const cp = playState.current_player
    if (!cp) return false
    if (cp === playState.dummy) {
      return positionRoles[playState.contract?.declarer] === 'human'
    }
    return positionRoles[cp] === 'human'
  }

  // 牌桌DD提示获取（P1 修复：300ms 防抖 + AbortController 取消在途请求，
  // 避免每次出牌/撤销都连发 DDS 求解请求在服务端堆积）
  useEffect(() => {
    if (!showPlayPanel || !playState) return
    if (!showDDHints) { setDDHints(null); return }

    // 只要四家手牌都已知就计算 DD（导入时已从 tricks 重建）
    const ALL_POS = ['南', '北', '东', '西']
    const suitMap = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' }
    const fullHands = {}
    let allKnown = true
    for (const p of ALL_POS) {
      const h = hands?.[p]
      if (h && ((h.spades || '') + (h.hearts || '') + (h.diamonds || '') + (h.clubs || '')).length > 0) {
        fullHands[p] = []
        for (const sk of ['spades', 'hearts', 'diamonds', 'clubs']) {
          for (const r of (h[sk] || '')) {
            if ('AKQJT98765432'.includes(r.toUpperCase())) fullHands[p].push({ suit: suitMap[sk], rank: r.toUpperCase() })
          }
        }
      } else {
        allKnown = false
      }
    }
    if (!allKnown) { setDDHints(null); return }

    const controller = new AbortController()
    const timer = setTimeout(() => {
      // 复盘：通过游标重建牌局快照
      if (reviewCursor != null) {
        const totalCards = (playState.tricks || []).reduce((s, t) => s + (t.cards?.length || 0), 0)
          + (playState.current_trick?.cards?.length || 0)
        if (reviewCursor >= totalCards) { setDDHints(null); return }
        setDDHints(null)
        setDDHintsLoading(true)
        getDDHintsReview({ ...playState, hands: fullHands }, reviewCursor, controller.signal)
          .then(data => { if (!controller.signal.aborted && data?.success) setDDHints(data.hints) })
          .catch(err => {
            if (!controller.signal.aborted && err.name !== 'CanceledError' && err.name !== 'AbortError') {
              console.error('DD hints review fetch failed:', err)
            }
          })
          .finally(() => { if (!controller.signal.aborted) setDDHintsLoading(false) })
        return
      }

      // 实战：直接用后端当前状态
      if (playState.phase === 'complete') return
      setDDHints(null)
      setDDHintsLoading(true)
      getDDHints(controller.signal)
        .then(data => { if (!controller.signal.aborted && data?.success) setDDHints(data.hints) })
        .catch(err => {
          if (!controller.signal.aborted && err.name !== 'CanceledError' && err.name !== 'AbortError') {
            console.error('DD hints fetch failed:', err)
          }
        })
        .finally(() => { if (!controller.signal.aborted) setDDHintsLoading(false) })
    }, 300)
    return () => { clearTimeout(timer); controller.abort() }
  }, [showDDHints, playState?.current_player, playState?.phase, showPlayPanel, reviewCursor, playState, hands, setDDHints, setDDHintsLoading])

  // 加载记录后自动进入打牌界面（记录含打牌数据时）
  useEffect(() => {
    if (loadedPlayRecord) {
      handleStartPlay()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loadedPlayRecord])

  // AI 自动出牌（v1.61 重构）：由回合状态显式驱动，不再依赖 aiThinking 翻转链条。
  // - aiThinking 仅作"AI 思考中"旋转指示（指示器清除由下方独立 effect 负责）
  // - 调度触发源：current_player（墩内轮转）/ tricks.length（第四家赢墩后继续领出，
  //   current_player 不变，只有墩数变化）/ hands / current_trick（手动补手牌后恢复）
  // - 防重复调度：aiPlayInFlightRef 覆盖"调度→后端确认"全程；乐观更新期间
  //   current_player/tricks.length 不变，在途标记挡住同回合二次调度；后端确认推进后
  //   重新评估并调度下一家。暂停/继续/撤销/重打均自然衔接，无需手动翻转 aiThinking。
  useEffect(() => {
    if (!showPlayPanel || !playState || !playInitiated) return
    if (isPlayPaused || playLoading) return
    const { phase } = playState
    if (phase === 'complete') return
    const isHuman = isCurrentPlayerHuman()
    if (isHuman) return
    const cp = playState.current_player
    if (!cp) return
    // P2-8：AI 缺手牌不再静默卡住——提示错误并暂停，用户输入手牌后可继续
    // 注意：phase === 'complete' 已在上方拦截，打完 13 墩后四家空手牌不会误报
    const currentHand = playState.hands?.[cp]
    if (!currentHand || currentHand.length === 0) {
      setError(`AI出牌受阻：${cp}家手牌缺失，请先在牌桌输入该家手牌后点击"继续"`)
      setIsPlayPaused(true)
      return
    }
    if (aiPlayInFlightRef.current) return // 出牌请求在途，等后端确认后本 effect 重新评估

    const legalPlays = getLegalPlaysForPlayer(cp)
    if (legalPlays.length === 0) return

    setAiThinking(true)
    const timer = setTimeout(() => {
      if (legalPlays.length === 1) {
        handlePlayCard(cp, legalPlays[0])
      } else {
        handleAIPlay()
      }
    }, 250)
    return () => clearTimeout(timer)
  }, [showPlayPanel, playState?.current_player, playState?.tricks?.length, playState?.current_trick?.cards?.length, playState?.hands, playState?.phase, playInitiated, isPlayPaused, playLoading])

  // 仅剩一张合法出牌时自动打出（无需用户选择）
  useEffect(() => {
    if (!showPlayPanel || !playState || aiThinking || playLoading || !playInitiated) return
    if (isPlayPaused) return // 暂停/撤销后不自动出牌，等用户点击"继续"
    if (playState.phase === 'complete') return
    const cp = playState.current_player
    if (!cp) return
    const isHuman = positionRoles[cp] === 'human' || (cp === playState.dummy && positionRoles[playState.contract?.declarer] === 'human')
    if (!isHuman) return
    const legalPlays = getLegalPlaysForPlayer(cp)
    if (legalPlays.length === 1) {
      const card = legalPlays[0]
      const timer = setTimeout(() => handlePlayCard(cp, card), 400)
      return () => clearTimeout(timer)
    }
  }, [playState?.current_player, playState?.current_trick, playState?.hands, showPlayPanel, playInitiated, aiThinking, playLoading, isPlayPaused])

  // 轮到人类出牌时自动暂停（每墩首张除外，由继续按钮控制）
  useEffect(() => {
    if (!showPlayPanel || !playState || aiThinking || playLoading || !playInitiated) return
    const isHuman = isCurrentPlayerHuman()
    const isStartOfTrick = (playState.current_trick?.cards?.length || 0) === 0
    const onlyOneLegal = isHuman && getLegalPlaysForPlayer(playState.current_player).length === 1
    if (isHuman && playState.phase !== 'complete' && !isPlayPaused && !isStartOfTrick && !onlyOneLegal) {
      setIsPlayPaused(true)
    }
  }, [playState?.is_human_turn, playState?.phase, showPlayPanel, playInitiated, aiThinking, playLoading, isPlayPaused, positionRoles, playState?.current_trick, playState?.hands])

  // 打牌计时开始（v1.61）：playInitiated 变 true（开始打牌/重打/复盘重打）时记录开始时间；
  // 暂停/继续不重置，总耗时=从进入打牌到完成的墙钟时间
  useEffect(() => {
    if (playInitiated && showPlayPanel) {
      playStartTimeRef.current = Date.now()
      setPlayStartTime(playStartTimeRef.current)
      setPlayTotalTime(null)
    }
  }, [playInitiated, showPlayPanel])

  // 检测一墩完成，自动暂停；检测打牌完成，自动保存记录
  // 仅真实打牌时运行；载入历史记录回放（loadedPlayRecord）时不触发，避免清空复盘游标
  useEffect(() => {
    if (!showPlayPanel || !playState || loadedPlayRecord) return

    const currentTricksCount = playState.tricks?.length || 0
    const prevTricksCount = prevTricksCountRef.current
    const phase = playState.phase

    // 一墩完成时不自动暂停（连续自动打牌，手动暂停按钮仍可用）
    if (currentTricksCount > prevTricksCount && playState.tricks && playState.tricks.length > 0) {
      const lastTrick = playState.tricks[playState.tricks.length - 1]
      setLastCompletedTrick(lastTrick)
      setSelectedPlayRecord(null)
    }

    // 打牌完成，自动保存完整记录；停留在完成状态，不自动进入复盘
    if (phase === 'complete' && prevTricksCount < 13) {
      console.log('[自动保存] 打牌完成 phase=complete, 准备保存完整记录');
      // v1.61：计算打牌总耗时（打牌开始时间在 playInitiated 变 true 时记录）
      if (playStartTimeRef.current) {
        setPlayTotalTime(Math.max(0, Math.round((Date.now() - playStartTimeRef.current) / 1000)))
      }
      saveCompletePlayRecord()
      setReviewCursor(null)
    }

    prevTricksCountRef.current = currentTricksCount
  }, [playState?.tricks?.length, playState?.phase, showPlayPanel])

  // AI 思考指示清除（v1.61）：aiThinking 仅作旋转指示，只在 AI 回合出牌过程中为 true；
  // 人类回合 / 暂停 / 完成 / 离开打牌（返回叫牌、复盘载入完成态）时立即清除，
  // 避免旋转不停、计时不增（复盘载入完成态同样覆盖）
  useEffect(() => {
    if (!showPlayPanel || playState?.phase === 'complete' || isPlayPaused || isCurrentPlayerHuman()) {
      setAiThinking(false)
    }
  }, [showPlayPanel, playState?.phase, playState?.is_human_turn, playState?.current_player, isPlayPaused, positionRoles])

  // 保存打牌完成的完整记录
  const saveCompletePlayRecord = useCallback(() => {
    if (!playState || playState.phase !== 'complete') return

    // 从第一墩第一张牌提取首攻
    let openingLead = imageOpeningLead || undefined
    if (!openingLead && playState.tricks?.length > 0) {
      const firstTrick = playState.tricks[0]
      if (firstTrick.cards?.length > 0) {
        const [leadPos, leadCard] = firstTrick.cards[0]
        openingLead = `${leadPos}:${leadCard.suit}${leadCard.rank}`
      }
    }

    const finalContract = getFinalContract() || directPlayContractInfo
    const record = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleString(),
      type: 'play_complete',
      sourceRecordId: currentRecordId || undefined,
      board: {
        hands: hands,
        bidding_sequence: biddingSequence,
        contract: finalContract,
        dealer: dealer,
        game_mode: gameMode,
        practice_direction: practiceDirection,
        position_roles: positionRoles,
        opening_lead: openingLead,
      },
      bidding: {
        ai_bidding_history: trimBiddingHistory(aiBiddingHistory),
        deal_system: dealSystem,
      },
      play: {
        tricks: playState.tricks,
        ai_play_history: trimPlayHistory(aiPlayHistory),
        declarer_tricks: playState.declarer_tricks,
        defender_tricks: playState.defender_tricks,
      },
      note: ''
    }
    saveBridgeRecord(record)
    console.log('[自动保存] 打牌记录已调用保存, id:', record.id)
    // 如果之前没有记录ID，保存后设置当前记录ID
    if (!currentRecordId) {
      setCurrentRecordId(record.id)
    }
  }, [playState, hands, biddingSequence, dealer, gameMode, practiceDirection, positionRoles, directPlayContractInfo, aiBiddingHistory, dealSystem, aiPlayHistory, currentRecordId, imageOpeningLead])

  // 处理位置角色变化：所有位置全手动设置，无连锁
  const handlePositionRoleChange = useCallback(async (position, role) => {
    const newRoles = { ...positionRoles, [position]: role }
    setPositionRoles(newRoles)

    // 每墩开头：当前玩家从人类切为AI时自动暂停，显示继续按钮
    if (showPlayPanel && playState && !isPlayPaused && playState.phase !== 'complete') {
      const isStartOfTrick = (playState.current_trick?.cards?.length || 0) === 0
      if (isStartOfTrick && newRoles[playState.current_player] === 'ai') {
        setIsPlayPaused(true)
      }
    }

    // 如果在打牌阶段，同步更新后端的 player_roles
    if (showPlayPanel && playState) {
      try {
        const result = await updatePlayPlayerRoles(newRoles)
        if (result.success) {
          setPlayState(result.state)
        }
      } catch (err) {
        console.error('更新打牌角色失败:', err)
      }
    }
  }, [positionRoles, showPlayPanel, playState, isPlayPaused, setPositionRoles, setIsPlayPaused, setPlayState])

  // 打开修正手牌对话框（稳定引用，供 memo 子组件）
  const handleOpenEditHands = useCallback(() => {
    setCustomDealText(handsToEditText(hands))
    setCustomDealOpen(true)
  }, [hands, setCustomDealOpen])

  // 打开编辑叫牌序列对话框
  const handleOpenEditBidding = useCallback(() => {
    setEditBiddingText(biddingToEditText(biddingSequence))
    setShowEditBiddingDialog(true)
  }, [biddingSequence, setShowEditBiddingDialog])

  // 打开自定义发牌对话框
  const handleOpenCustomDeal = useCallback(() => setCustomDealOpen(true), [setCustomDealOpen])

  // 图片发牌：带 File 参数时直接识别，否则打开图片发牌对话框
  const handleImageDealProp = useCallback((file) => file ? handleImageDeal(file) : setImageDealOpen(true), [handleImageDeal, setImageDealOpen])


  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto', py: { xs: 1.5, md: 2.5 }, px: { xs: 1, md: 3 } }}>
      {/* 草稿恢复提示横幅 */}
      {showDraftBanner && (
        <Alert
          severity="warning"
          sx={{ mb: 2 }}
          action={
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button color="inherit" size="small" onClick={clearBiddingDraft}>
                忽略
              </Button>
              <Button color="primary" size="small" variant="outlined" onClick={restoreBiddingDraft}>
                恢复
              </Button>
            </Box>
          }
        >
          检测到上次未完成的叫牌，是否需要恢复？
        </Alert>
      )}
      <Header
        onModeChange={handleModeChange}
        mode={mode}
        showSettings={showSettings}
        setShowSettings={setShowSettings}
        loading={loading}
        handleDeal={handleDeal}
        dealMode={dealMode}
        biddingRecords={bridgeRecords}
        setHistoryDialogOpen={setHistoryDialogOpen}
        checkApiStatus={checkApiStatus}
        apiStatus={apiStatus}
        handleReloadJF={handleReloadJF}
        darkMode={darkMode}
        onToggleDarkMode={onToggleDarkMode}
        aiThinking={aiThinking}
      />
      {/* 游戏设置 */}
      <SettingsPanel
        isMobile={isMobile}
        showSettings={showSettings}
        fallbackModel={fallbackModel}
        handleFallbackModelChange={handleFallbackModelChange}
        playModel={playModel}
        handlePlayModelChange={handlePlayModelChange}
        playEngine={playEngine}
        handlePlayEngineChange={handlePlayEngineChange}
        useLlmReview={useLlmReview}
        handleLlmReviewChange={handleLlmReviewChange}
        ddSampleCount={ddSampleCount}
        handleDDSampleCountChange={handleDDSampleCountChange}
        ddParticles={ddParticles} ddParticlesRange={ddParticlesRange}
        mctsParticles={mctsParticles} mctsParticlesRange={mctsParticlesRange}
        alphaMuParticles={alphaMuParticles} alphaMuParticlesRange={alphaMuParticlesRange}
        handleParticleChange={handleParticleChange}
        switchCards={switchCards} switchCardsRange={switchCardsRange}
        handleSwitchCardsChange={handleSwitchCardsChange}
        ddScoringMode={ddScoringMode} handleDdScoringModeChange={handleDdScoringModeChange}
        dealSystem={dealSystem}
        setDealSystem={setDealSystem}
        bidSystem={bidSystem}
        setBidSystem={setBidSystem}
        dealMode={dealMode}
        setDealMode={setDealMode}
        humanBidInterpret={humanBidInterpret}
        setHumanBidInterpret={setHumanBidInterpret}
        loading={loading}
        mode={mode}
        hands={hands}
        availableModels={availableModels}
      />

      {/* 错误提示（P1-7：关闭错误横幅不再隐式取消截屏轮询） */}
      {error && (
        <Alert severity="error" onClose={() => setError(null)} sx={{ mb: 1 }}>
          {error}
        </Alert>
      )}
      {/* P1-7：截屏/识别进度（info 样式 + 显式取消按钮） */}
      {screenshotStatus && (
        <Alert
          severity="info"
          icon={<CircularProgress size={18} />}
          sx={{ mb: 1 }}
          action={
            <Button
              color="inherit"
              size="small"
              onClick={cancelScreenshot}
              sx={{ fontSize: '0.7rem', textTransform: 'none' }}
            >
              取消截屏
            </Button>
          }
        >
          {screenshotStatus}
        </Alert>
      )}
      {warning && (
        <Alert
          severity="warning"
          onClose={() => setWarning(null)}
          sx={{ mb: 3 }}
        >
          {warning}
        </Alert>
      )}

      {/* P1-9：历史回放进度（载入记录 / 倒回重打时显示） */}
      {replayProgress && replayProgress.total > 0 && (
        <Alert
          severity="info"
          icon={<CircularProgress size={18} />}
          sx={{ mb: 1, '& .MuiAlert-message': { width: '100%' } }}
        >
          <Typography variant="body2" sx={{ fontSize: '0.85rem' }}>
            正在载入已出牌 {replayProgress.current}/{replayProgress.total} 张…
          </Typography>
          <LinearProgress
            variant="determinate"
            value={Math.min(100, (replayProgress.current / replayProgress.total) * 100)}
            sx={{ mt: 0.5 }}
          />
        </Alert>
      )}

      {/* 牌桌主区域（桌面横排 / 手机纵排，由 MainTableArea 内部处理） */}
      {hands && (
        <MainTableArea
          isMobile={isMobile}
          declarer={finalContract?.declarer || directPlayContractInfo?.declarer}
          finalContract={finalContract}
          directPlayContractInfo={directPlayContractInfo}
          onAnalyzeContract={handleAnalyzeContract}
          onToggleDoubleDummy={toggleDoubleDummy}
          onCancelDoubleDummy={cancelDoubleDummy}
          onDealerChange={handleDealerChange}
          onPositionRoleChange={handlePositionRoleChange}
          onClearAllHands={clearAllHands}
          onEditHands={handleOpenEditHands}
          onEditBidding={handleOpenEditBidding}
          onPlayCardClick={handlePlayCardClick}
          onSetPlayHand={handleSetPlayHand}
          onImageDeal={handleImageDealProp}
          onScreenshotDeal={onScreenshotDeal}
          onScreenshotBidding={onScreenshotBidding}
          screenshotBiddingDisabled={dealingLoading || aiThinking}
          onSingleHandScreenshot={handleSingleHandScreenshot}
          onSingleHandUpload={handleSingleHandUpload}
          onCustomDeal={handleOpenCustomDeal}
          onDeal={handleDeal}
          onHandCardClick={handleHandCardClick}
          onManualPlay={handleManualPlay}
          addBid={addBid}
          startBidding={startBidding}
          // 叫牌面板回调
          onStartPlay={handleStartPlay}
          onResetBidding={resetBidding}
          onToggleStopBidding={toggleStopBidding}
          onUndoBidding={undoBidding}
          onSaveBidding={handleSaveProgress}
          canSaveBiddingProgress={canSaveProgress}
          showUndoBidding={showUndo}
          canUndoBidding={canUndo}
          onStartBidding={startBidding}
          // 打牌面板回调
          onResume={handleResumePlay}
          onResetPlay={handleResetPlay}
          onClearExternalRecord={() => setSelectedPlayRecord(null)}
          onBeginPlay={handleBeginPlay}
          onPausePlay={handlePausePlay}
          onUndoPlay={handleUndoPlay}
          onSavePlay={handleSaveProgress}
          canSavePlay={playCanSave}
          onBackToBidding={handleBackToBidding}
          onReviewPrev={() => setReviewCursor(c => Math.max(0, (c || 0) - 1))}
          onReviewNext={() => setReviewCursor(c => {
            const totalCards = (playState?.tricks || []).reduce((s, t) => s + (t.cards?.length || 0), 0)
              + (playState?.current_trick?.cards?.length || 0)
            return Math.min(totalCards, (c || 0) + 1)
          })}
          onRewindToTrick={handleRewindToTrick}
          onReviewCompletedPlay={handleReviewCompletedPlay}
          playTotalTime={playTotalTime}
        />
      )}

      {/* 使用说明 */}
      {!hands && (
        <Paper elevation={1} sx={{ p: 3, mt: 4 }}>
          <Typography variant="h6" gutterBottom>
            使用说明
          </Typography>
          <Typography variant="body1" component="div">
            <strong>开始练习：</strong><br />
            1. 点击"设置"选择叫牌模式（四人/双人）、发牌人位置和人类玩家位置<br />
            2. 点击"发牌"生成新牌局，或使用自定义牌局/图片识别功能<br />
            3. 人类回合时右侧面板显示叫牌按钮，AI回合自动叫牌<br />
            <br />
            <strong>界面说明：</strong><br />
            • 当前牌局：可切换显示小房子/叫牌结果，勾选显示AI手牌或队友手牌<br />
            • 叫牌细节：人类叫牌时显示JF约定片段作为参考
          </Typography>
        </Paper>
      )}

      {/* 历史记录对话框 */}
      <HistoryDialog
        open={historyDialogOpen}
        onClose={() => setHistoryDialogOpen(false)}
        records={bridgeRecords}
        onLoad={loadRecordToTable}
        onDelete={(ids) => deleteBridgeRecords(ids)}
        onExport={(summaries) => {
          (async () => {
            try {
              if (summaries.length === 0) { setError('没有可导出的记录'); return }
              // 摘要列表只有轻量字段，导出需从后端取完整记录
              const ids = summaries.map(r => r.id)
              const full = ids.length ? await fetchFullRecords(ids) : []
              const exportData = { version: '2.0', exportDate: new Date().toISOString(), records: full }
              const dataStr = JSON.stringify(exportData, null, 2)
              const blob = new Blob([dataStr], { type: 'application/json' })
              const url = URL.createObjectURL(blob)
              const link = document.createElement('a')
              link.href = url
              link.download = `bridge_records_${new Date().toISOString().slice(0, 10)}.json`
              document.body.appendChild(link)
              link.click()
              document.body.removeChild(link)
              URL.revokeObjectURL(url)
            } catch (err) {
              console.error('导出记录失败:', err)
              setError('导出记录失败')
            }
          })()
        }}
        onImport={importRecords}
        onUpdateNote={updateRecordNote}
        onError={setError}
        onGetFull={fetchFullRecord}
      />

      {/* 自定义牌局对话框 */}
      <Dialog open={customDealOpen} onClose={() => { setCustomDealOpen(false); setHandsValidationError([]); setHandsValidationWarning([]) }} maxWidth="md" fullWidth>
        <DialogTitle>修正手牌</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            支持多种格式（按南西北东顺序，每行一家）：<br />
            格式1 - 标准格式：<br />
            K85 AT863 Q42 63<br />
            格式2 - 带花色符号（修正手牌时使用）：<br />
            ♠KT85 ♥AT863 ♦Q42 ♣63<br />
            格式3 - Deep Finesse格式<br />
            <br />
            用 - 或空字符串表示缺门。行内用空格分隔四个花色。<br />
            允许只修改部分玩家：未编辑的位置（0张）保留原手牌数据。
          </Alert>
          <TextField
            multiline
            rows={8}
            fullWidth
            value={customDealText}
            onChange={(e) => { setCustomDealText(e.target.value); setHandsValidationError([]); setHandsValidationWarning([]) }}
            placeholder="请输入牌局..."
          />
          {handsValidationError.length > 0 && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {handsValidationError.map((err, i) => (<div key={i}>• {err}</div>))}
            </Alert>
          )}
          {handsValidationWarning.length > 0 && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              {handsValidationWarning.map((w, i) => (<div key={i}>• {w}</div>))}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setCustomDealOpen(false); setHandsValidationError([]); setHandsValidationWarning([]) }}>取消</Button>
          <Button onClick={async () => {
            if (!customDealText.trim()) return
            // 解析原始文本，记录每行是否为空（用于区分"未编辑"和"主动清空"）
            const rawLines = customDealText.split('\n')
            const posOrder = ['南', '西', '北', '东']
            const lineIsEmpty = posOrder.map((_, i) => !(rawLines[i] || '').trim())

            // 直接调用解析API，不使用 handleCustomDeal（避免 resetGameState 清空打牌/叫牌状态）
            setLoading(true)
            let parsedHands
            try {
              const resp = await apiCustomDeal(customDealText)
              if (!resp.success) {
                setHandsValidationError([resp.message || '牌局解析失败'])
                return
              }
              parsedHands = resp.hands
            } catch {
              setHandsValidationError(['牌局解析失败，请检查API服务'])
              return
            } finally {
              setLoading(false)
            }

            // 校验手牌：每家13张或0张、无重复、四家52张（仅当四家都有牌时）
            const validation = validateHands(parsedHands)
            if (!validation.valid) {
              setHandsValidationError(validation.errors)
              setHandsValidationWarning(validation.warnings)
              return
            }
            // 合并：空行保留原数据（未编辑），非空行使用新数据（包括0张主动清空）
            const mergedHands = { ...parsedHands }
            for (let i = 0; i < 4; i++) {
              if (lineIsEmpty[i] && hands?.[posOrder[i]]) {
                mergedHands[posOrder[i]] = { ...hands[posOrder[i]] }
              }
            }
            setHands(mergedHands)
            // 打牌阶段：同步后端 playState（"修正后的完整牌 - 已打出牌 = 剩余牌"再同步，
            // 确保修正后的明手牌能正确驱动 AI 出牌，且不会把已打出的牌加回）
            if (showPlayPanel && playState) {
              const suitToKey = { '♠': 'spades', '♥': 'hearts', '♦': 'diamonds', '♣': 'clubs' }
              const played = {} // pos -> Set("suit rank")
              const collectPlayed = (trick) => {
                ;(trick?.cards || []).forEach(([pos, card]) => {
                  if (!played[pos]) played[pos] = new Set()
                  played[pos].add(`${card.suit}${card.rank}`)
                })
              }
              ;(playState.tricks || []).forEach(collectPlayed)
              collectPlayed(playState.current_trick)
              for (const pos of ['南', '西', '北', '东']) {
                const h = mergedHands[pos]
                if (!h) continue
                const cards = []
                for (const key of ['spades', 'hearts', 'diamonds', 'clubs']) {
                  for (const r of (h[key] || '')) {
                    cards.push({ suit: { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' }[key], rank: r.toUpperCase() })
                  }
                }
                const remainingCards = cards.filter(c => !played[pos]?.has(`${c.suit}${c.rank}`))
                if (remainingCards.length === 0) continue
                const remainingHand = { spades: '', hearts: '', diamonds: '', clubs: '' }
                remainingCards.forEach(c => { remainingHand[suitToKey[c.suit]] += c.rank })
                try {
                  const playResult = await setPlayHand(pos, remainingHand)
                  if (playResult?.success && playResult.state) setPlayState(playResult.state)
                } catch {
                  // 非打牌阶段调用失败，忽略
                }
              }
            }
            setHandsValidationError([])
            setHandsValidationWarning([])
            setCustomDealOpen(false)
            setCustomDealText('')
            // 修正后立即保存牌局，确保历史记录中是完整手牌
            saveBridgeRecord({
              id: currentRecordId || Date.now().toString(),
              timestamp: new Date().toLocaleString(),
              type: 'bidding_in_progress',
              board: {
                hands: mergedHands,
                bidding_sequence: [],
                contract: null,
                dealer: dealer,
                game_mode: gameMode,
                practice_direction: practiceDirection,
                position_roles: positionRoles,
              },
              bidding: { ai_bidding_history: [], deal_system: dealSystem },
              play: null,
              note: '',
            })
            if (currentRecordId) loadBridgeRecords()
          }} variant="contained" disabled={!customDealText.trim() || loading}>
            {loading ? <CircularProgress size={20} /> : '确定'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 编辑叫牌对话框 */}
      <Dialog open={showEditBiddingDialog} onClose={() => { setShowEditBiddingDialog(false); setBiddingValidationError([]); setBiddingValidationWarning([]) }} maxWidth="md" fullWidth>
        <DialogTitle>编辑叫牌序列</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            格式：(位置)叫品，用 - 分隔。例如：(北)pass-(东)1H-(南)pass-(西)2D-...
          </Alert>
          <TextField
            multiline
            rows={4}
            fullWidth
            value={editBiddingText}
            onChange={(e) => { setEditBiddingText(e.target.value); setBiddingValidationError([]); setBiddingValidationWarning([]) }}
            placeholder="输入叫牌序列..."
          />
          {biddingValidationError.length > 0 && (
            <Alert severity="error" sx={{ mt: 2 }}>
              {biddingValidationError.map((err, i) => (<div key={i}>• {err}</div>))}
            </Alert>
          )}
          {biddingValidationWarning.length > 0 && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              {biddingValidationWarning.map((w, i) => (<div key={i}>• {w}</div>))}
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setShowEditBiddingDialog(false); setBiddingValidationError([]); setBiddingValidationWarning([]) }}>取消</Button>
          <Button onClick={() => {
            if (editBiddingText.trim()) {
              const parsed = parseBiddingSequenceStr(editBiddingText)
              if (parsed.length === 0) {
                setBiddingValidationError(['叫牌格式解析失败，请检查格式'])
                return
              }
              // 校验叫牌：位置连续性、叫品合法性、阶数递增、X/XX合法性
              const validation = validateBidding(parsed, dealer)
              if (!validation.valid) {
                setBiddingValidationError(validation.errors)
                setBiddingValidationWarning(validation.warnings)
                return
              }
              setBiddingValidationError([])
              setBiddingValidationWarning(validation.warnings)
              // 使用标准化后的序列（处理pass=、X、XX等）
              setBiddingSequence(validation.normalized)
              setShowEditBiddingDialog(false)
            }
          }} variant="contained">
            确定
          </Button>
        </DialogActions>
      </Dialog>

      {/* 图片牌局对话框 */}
      <Dialog open={imageDealOpen} onClose={() => setImageDealOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>从图片读取牌局</DialogTitle>
        <DialogContent>
          <Alert severity="info" sx={{ mb: 2 }}>
            支持 jpg/png/gif/webp 格式的图片
          </Alert>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <TextField
              fullWidth
              value={imagePath}
              placeholder="请选择图片文件..."
              InputProps={{ readOnly: true }}
            />
            <Button
              variant="outlined"
              component="label"
              sx={{ flexShrink: 0, whiteSpace: 'nowrap' }}
            >
              浏览...
              <input
                type="file"
                accept="image/*"
                hidden
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) {
                    setImagePath(file.name)
                    setImageFile(file)
                  }
                }}
              />
            </Button>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setImageDealOpen(false)
            setImagePath('')
            setImageFile(null)
          }}>取消</Button>
          <Button onClick={async () => {
            if (imageFile) {
              await handleImageDeal(imageFile)
              setImageDealOpen(false)
              setImagePath('')
              setImageFile(null)
            }
          }} variant="contained" disabled={!imageFile || loading}>
            {loading ? <CircularProgress size={20} /> : '确定'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 进入打牌前确认/调整定约与首攻 */}
      <Dialog open={contractDialogOpen} onClose={() => setContractDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>确认定约与首攻</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 1 }}>
            <Alert severity={contractDialogForm.contractStr ? 'success' : 'info'}>
              {contractDialogForm.contractStr
                ? '已识别到定约信息，确认或调整后开始打牌'
                : '未检测到定约，请手动输入后进入打牌'}
            </Alert>
            <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'flex-start' }}>
              <TextField
                label="定约"
                placeholder="例如 4S 或 3NT"
                value={contractDialogForm.contractStr}
                onChange={(e) => setContractDialogForm({ ...contractDialogForm, contractStr: e.target.value.replace(/\s/g, '').toUpperCase() })}
                size="small"
                sx={{ flex: '0 0 140px' }}
                onKeyDown={(e) => { if (e.key === 'Enter') handleContractDialogConfirm() }}
              />
              <FormControl size="small" sx={{ flex: '0 0 100px' }}>
                <InputLabel>庄家</InputLabel>
                <Select
                  value={contractDialogForm.declarer}
                  label="庄家"
                  onChange={(e) => setContractDialogForm({ ...contractDialogForm, declarer: e.target.value })}
                >
                  {['南', '北', '东', '西'].map(pos => (
                    <MenuItem key={pos} value={pos}>{pos}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <ToggleButtonGroup
                size="small"
                value={
                  contractDialogForm.isRedouble ? 'XX' :
                  contractDialogForm.isDouble ? 'X' : ''
                }
                exclusive
                onChange={(_, val) => {
                  if (val === null) return
                  setContractDialogForm({
                    ...contractDialogForm,
                    isDouble: val === 'X' || val === 'XX',
                    isRedouble: val === 'XX',
                  })
                }}
              >
                <ToggleButton value="" sx={{ fontSize: '0.75rem', px: 1 }}>—</ToggleButton>
                <ToggleButton value="X" sx={{ fontSize: '0.75rem', px: 1, fontWeight: 700 }}>X</ToggleButton>
                <ToggleButton value="XX" sx={{ fontSize: '0.75rem', px: 1, fontWeight: 700 }}>XX</ToggleButton>
              </ToggleButtonGroup>
            </Box>
            <TextField
              label="首攻（可选）"
              placeholder="如 西:S5 或留空"
              value={contractDialogForm.openingLead}
              onChange={(e) => setContractDialogForm({ ...contractDialogForm, openingLead: e.target.value })}
              size="small"
              fullWidth
              helperText="格式：位置:花色牌面，如 西:S5。留空则由AI自动决策"
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setContractDialogOpen(false)}>取消</Button>
          <Button onClick={handleContractDialogConfirm} variant="contained">开始打牌</Button>
        </DialogActions>
      </Dialog>

      {/* 载入已完成牌局 — 复盘 / 只重新打牌 二选一对话框 */}
      <Dialog
        open={recordActionDialogOpen}
        onClose={() => {
          if (recordActionMode) return
          setRecordActionDialogOpen(false)
        }}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle sx={{ fontSize: '1rem' }}>载入已完成牌局</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, mt: 1 }}>
            <Button
              variant="contained"
              color="primary"
              fullWidth
              onClick={() => confirmRecordAction('review')}
            >
              复盘
            </Button>
            <Typography variant="caption" color="text.secondary">
              载入已有出牌与 DD 最佳分析（hint），逐张查看整局。
            </Typography>
            <Button
              variant="outlined"
              color="primary"
              fullWidth
              onClick={() => confirmRecordAction('replay')}
            >
              只重新打牌
            </Button>
            <Typography variant="caption" color="text.secondary">
              从这副牌重新开始打牌，不载入已有出牌与 DD 数据。
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRecordActionDialogOpen(false)}>取消</Button>
        </DialogActions>
      </Dialog>

      {/* 重新打牌 — 首攻确认对话框 */}
      <Dialog open={resetOpeningLeadDialogOpen} onClose={() => setResetOpeningLeadDialogOpen(false)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ fontSize: '1rem' }}>重新打牌 — 首攻牌</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, mt: 1 }}>
            {imageOpeningLead ? (
              <Typography variant="body2" color="text.secondary">
                当前首攻: <strong>{imageOpeningLead}</strong>
              </Typography>
            ) : (
              <Typography variant="body2" color="text.secondary">
                当前无首攻（AI 决定）
              </Typography>
            )}
            <TextField
              label="修改首攻"
              value={resetOpeningLeadValue}
              onChange={(e) => setResetOpeningLeadValue(e.target.value)}
              size="small"
              fullWidth
              placeholder="如 西:S5，留空则清除"
              helperText="留空 + 点击「清除」= AI自行决定首攻"
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'space-between', px: 3, pb: 2 }}>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button onClick={() => handleResetOpeningLeadConfirm('clear')} color="error" variant="outlined" size="small">
              清除
            </Button>
            <Button onClick={() => handleResetOpeningLeadConfirm('edit')} color="primary" variant="outlined" size="small">
              修改
            </Button>
          </Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button onClick={() => { setResetOpeningLeadDialogOpen(false) }} size="small">取消</Button>
            <Button onClick={() => handleResetOpeningLeadConfirm('keep')} variant="contained" size="small">
              保留
            </Button>
          </Box>
        </DialogActions>
      </Dialog>
    </Box>
  )
}

function App({ darkMode, onToggleDarkMode }) {
  return (
    <GameProvider>
      <BiddingProvider>
        <PlayProvider>
          <AIProgressProvider>
            <AppShell darkMode={darkMode} onToggleDarkMode={onToggleDarkMode} />
          </AIProgressProvider>
        </PlayProvider>
      </BiddingProvider>
    </GameProvider>
  )
}


export default App
